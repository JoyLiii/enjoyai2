# -*- coding: utf-8 -*-
"""
Created on Mon Apr 26 15:55:14 2021

@author: JoyWCLi
"""
import argparse #承接網頁傳回的參數
import os
os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'
os.environ['path'] = r'D:/oracle/product/11.2.0/client_1/instantclient-basic-windows.x64-11.2.0.4.0/instantclient_11_2/' 
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import configparser





if __name__== "__main__":    
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--file_path_name', type=str, default="")
    parser.add_argument('--target', type=str, default="")
    args = parser.parse_args() 
    file_path_name  = args.file_path_name #檔案路徑 + 檔案名稱
    target  = args.target #目標
    # i_dataset_number = "210318190517"  
    # i_img_path = i_img_path.replace('\\' , '//')
    
    # file_path_name = '210408142341' 
    # target = 'Y'
    # =============================================================================
    # 取得資料路徑並將dataset讀取成dataframe
    # =============================================================================
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])
    
    
    # server = '10.96.48.148' #IP:port
    # DBuser = 'automl'
    # password = 'automl$0'
    # database = 'automl_db'
    # port = 3306
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')
        
    #SQL語句,可以定製,實現靈活查詢
    sql = f"SELECT * FROM automl_db.databse_info2 where Dataset_number = '{file_path_name}';"
    
    
    # 使用pandas 的read_sql函式,可以直接將資料存放在dataframe中
    results = pd.read_sql(sql,db) 
    tmp_dataset_name = str(results.Dataset_path[0])
    tmp_dataset_path = f"D:\\joy\\automl_upload_file\\{file_path_name}\\{tmp_dataset_name}"
    dataset = pd.read_excel(f'{tmp_dataset_path}')
    data = dataset.copy()
    # =============================================================================
    # 低方差的特徵
    # target 僅用來不被放入drop list中，因此可以在新增資料就計算
    # =============================================================================
    to_drop= []
    sampl_len = len(data[target])
    
    # for i in data.drop(target,axis=1).columns:
    for i in data.columns:
      # get the number of unique counts
      u = pd.DataFrame( data[i].value_counts()).sort_values(by=i,ascending=False, inplace=False)
      # take len of u and divided it by the total sample numbers, so this will check the 1st rule , has to be low say 10%
      #import pdb; pdb.set_trace()
      first=len(u)/sampl_len
      # then check if most common divided by 2nd most common ratio is 20 or more
      if len(u[i]) == 1: # this means that if column is non variance , automatically make the number big to drop it
        second=100
      else:
        second = u.iloc[0,0]/u.iloc[1,0]
    # if both conditions are true then drop the column, however, we dont want to alter column that indicate NA's
      if ((first <= 0.10) and (second >=20) and (i[-10:]!='_surrogate')):
        to_drop.append(i) 
    # now drop if the column has zero variance
      if (((second ==100) and (i[-10:]!='_surrogate'))):
        to_drop.append(i) 
    to_drop2 = set(to_drop)
    to_drop = list(to_drop2)
    
    if (len(to_drop) == 1):
        Str_to_drop = to_drop[0] + "!next!"
    else:  
        Str_to_drop = "!next!".join(to_drop)
    print(Str_to_drop)

    
# =============================================================================
# 共線性特徵
# =============================================================================


# threshold = 0.9
# target_variable = "Y"
# correlation_with_target_threshold= 0.0
# target_corr_weight = 0.9
# multicol_weight = 1 - 0.08

# if dataset[target_variable].dtypes == "object":
#     from sklearn.preprocessing import LabelEncoder
#     labelencoder = LabelEncoder()
#     data_le = pd.DataFrame(dataset)
#     data_le[target_variable] = labelencoder.fit_transform(data_le[target_variable])

# #global data1
# data1 = data_le.copy()
# data_numeric = data1._get_numeric_data()
# data1 = data_numeric.copy()
# # try:
# #   data1 = data1.astype('float16')
# # except:
# #   None
# # make an correlation db with abs correlation db
# # data_c = data1.T.drop_duplicates()
# # data1 = data_c.T
# corr = pd.DataFrame(np.corrcoef(data1.T))
# corr.columns = data1.columns
# corr.index = data1.columns
# # corr_matrix = abs(data1.corr())
# corr_matrix = abs(corr)
# #    corr.to_csv("corr_x.csv")corr_x.csv
# # for every diagonal value, make it Nan
# corr_matrix.values[tuple([np.arange(corr_matrix.shape[0])]*2)] = np.NaN

# # Now Calculate the average correlation of every feature with other, and get a pandas data frame
# avg_cor = pd.DataFrame(corr_matrix.mean())
# avg_cor['feature']= avg_cor.index
# avg_cor.reset_index(drop=True, inplace=True)
# avg_cor.columns =  ['avg_cor','features']

# # Calculate the correlation with the target
# targ_cor = pd.DataFrame(corr_matrix[target_variable].dropna())
# targ_cor['feature']= targ_cor.index
# targ_cor.reset_index(drop=True, inplace=True)
# targ_cor.columns =  ['target_variable','features']

# # Now, add a column for variable name and drop index
# corr_matrix['column'] = corr_matrix.index
# corr_matrix.reset_index(drop=True,inplace=True)

# # now we need to melt it , so that we can correlation pair wise , with two columns 
# cols =corr_matrix.column
# melt = corr_matrix.melt(id_vars= ['column'],value_vars=cols).sort_values(by='value',ascending=False).dropna()

# # now bring in the avg correlation for first of the pair
# merge = pd.merge(melt,avg_cor,left_on='column',right_on='features').drop('features',axis=1)

# # now bring in the avg correlation for second of the pair
# merge = pd.merge(merge,avg_cor,left_on='variable',right_on='features').drop('features',axis=1)

# # now bring in the target correlation for first of the pair
# merge = pd.merge(merge,targ_cor,left_on='column',right_on='features').drop('features',axis=1)

# # now bring in the avg correlation for second of the pair
# merge = pd.merge(merge,targ_cor,left_on='variable',right_on='features').drop('features',axis=1)

# # sort and save
# merge = merge.sort_values(by='value',ascending=False)

# # we need to now eleminate all the pairs that are actually duplicate e.g cor(x,y) = cor(y,x) , they are the same , we need to find these and drop them
# merge['all_columns'] = merge['column'] + merge['variable']

# # this puts all the coresponding pairs of features togather , so that we can only take one, since they are just the duplicates
# merge['all_columns'] = [sorted(i) for i in merge['all_columns'] ]

# # now sort by new column
# merge = merge.sort_values(by='all_columns')

# # take every second colums
# merge = merge.iloc[::2, :]

# # make a ranking column to eliminate features
# merge['rank_x'] = round(multicol_weight*(merge['avg_cor_y']- merge['avg_cor_x']) +  target_corr_weight*(merge['target_variable_x'] - merge['target_variable_y']),6) # round it to 6 digits
# merge1 = merge # delete here
# ## Now there will be rows where the rank will be exactly zero, these is where the value (corelartion between features) is exactly one ( like price and price^2)
# ## so in that case , we can simply pick one of the variable
# # but since , features can be in either column, we will drop one column (say 'column') , only if the feature is not in the second column (in variable column)
# # both equations below will return the list of columns to drop from here 
# # this is how it goes

# ## For the portion where correlation is exactly one !
# one = merge[merge['rank_x']==0]

# # this portion is complicated 
# # table one have all the paired variable having corelation of 1
# # in a nutshell, we can take any column (one side of pair) and delete the other columns (other side of the pair)
# # however one varibale can appear more than once on any of the sides , so we will run for loop to find all pairs...
# # here it goes
# # take a list of all (but unique ) variables that have correlation 1 for eachother, we will make two copies
# u_all = list(pd.unique(pd.concat((one['column'],one['variable']),axis=0)))
# u_all_1 = list(pd.unique(pd.concat((one['column'],one['variable']),axis=0)))
# # take a list of features (unique) for the first side of the pair
# u_column  = pd.unique(one['column'])

# # now we are going to start picking each variable from one column (one side of the pair) , check it against the other column (other side of the pair)
# # to pull all coresponding / paired variables  , and delete thoes newly varibale names from all unique list

# for i in u_column:
#   #print(i)
#   r = one[one['column']==i]['variable'].values
#   for q in r:
#     if q in u_all:
#       #print("_"+q)
#       u_all.remove(q)

# # now the unique column contains the varibales that should remain, so in order to get the variables that should be deleted :
# to_drop =(list(set(u_all_1)-set(u_all)))


# # to_drop_a =(list(set(one['column'])-set(one['variable'])))
# # to_drop_b =(list(set(one['variable'])-set(one['column'])))
# # to_drop = to_drop_a + to_drop_b

# ## now we are to treat where rank is not Zero and Value (correlation) is greater than a specific threshold
# non_zero = merge[(merge['rank_x']!= 0.0) & (merge['value'] >= threshold)]

# # pick the column to delete
# non_zero_list = list(np.where(non_zero['rank_x'] < 0 , non_zero['column'], non_zero['variable']))

# # add two list
# to_drop = to_drop + non_zero_list

# #make sure that target column is not a part of the list
# try:
#     to_drop.remove(target_variable)
# except:
#     to_drop

# to_drop = to_drop
# print(to_drop)
# # now we want to keep only the columns that have more correlation with traget by a threshold
# to_drop_taret_correlation=[] 
# if correlation_with_target_threshold != 0.0:
#   corr = pd.DataFrame(np.corrcoef(data.drop(to_drop,axis=1).T),columns= data.drop(to_drop,axis=1).columns,index=data.drop(to_drop,axis=1).columns)
#   print(corr)
#   to_drop_taret_correlation = corr[target_variable].abs()
#   # to_drop_taret_correlation = data.drop(to_drop,axis=1).corr()[target_variable].abs()
#   to_drop_taret_correlation = to_drop_taret_correlation [to_drop_taret_correlation < correlation_with_target_threshold ]
#   to_drop_taret_correlation = list(to_drop_taret_correlation.index)
#   #to_drop = corr + to_drop
#   try:
#     to_drop_taret_correlation.remove(target_variable)
#   except:
#     to_drop_taret_correlation
  

#   # now Transform