import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from mlxtend.frequent_patterns import association_rules
from mlxtend.frequent_patterns import apriori

class RulesApriori:
    """
    Use the Apriori to find the association rules of NG(y=1).
    
    Parameters
    -----
    min_support : floot
        A float between 0 and 1 for minumum support of the itemsets returned.
    min_confidence : floot
        A float between 0 and 1 for minumum confidence of the candidate rules.
    min_lift : floot, default=1
        A float greater than 0 for minumum lift of candidate rules.
    check_size : int, default=22
        Define how many features are in a check.
    """
    
    def __init__(self, min_support, min_confidence, min_lift=1, check_size=22):
        """
        Initialization some parameters.
        """
        self.min_support = min_support
        self.min_confidence = min_confidence
        self.min_lift = min_lift
        self.check_size = check_size
    
    def OneHot(self, df_data, Input_categorical_col=[]):
        """
        Do the one hot encodind on columns with a value excluding 0 & 1.
        
        Parameters
        -----
        df_data : dataframe(pandas)
            Raw dataframe
        
        Returns
        -----
        df_data : dataframe(pandas)
            The dataframe after the one hot encoding.
        """
        df_data = df_data.fillna(0)
        
        ### Find a column that contains a value other than 0,1.
        onehot_columns = ((df_data!=0) & (df_data!=1)).any()
        need_to_do = onehot_columns.any()

        if need_to_do:
            ### Determine whether it is categorical data.
            less_than_5_class = (df_data.nunique() < 5)
            is_str = (df_data.dtypes == 'object')
            mask_Input_onehot_col = [(i in Input_categorical_col) for i in df_data.columns]
            less_then_5c_or_isstr_or_Input = (less_than_5_class | is_str | mask_Input_onehot_col)
            categorical_col = onehot_columns & less_then_5c_or_isstr_or_Input
            
            ### For continuous colume, use KMeans to divide into 4 clusters.
            continuous_col = onehot_columns & ~(less_then_5c_or_isstr_or_Input)
            if continuous_col.any():
                range_cluster = pd.DataFrame(columns=['cluster1_Center', 'cluster1_Range', 'cluster2_Center', 'cluster2_Range',
                                                    'cluster3_Center', 'cluster3_Range', 'cluster4_Center', 'cluster4_Range'])
                for col in df_data.columns[continuous_col]:
                    col_min = df_data[col].min()
                    col_max = df_data[col].max()
                    col_reshp = np.array(df_data[col]).reshape(-1,1)
                    kmeans = KMeans(n_clusters=4, random_state=0).fit(col_reshp)
                    col_transform = pd.Series(kmeans.predict(col_reshp))
                    
                    cluster_sort = kmeans.cluster_centers_.ravel().argsort()
                    dic_cluster_sort = dict(zip(cluster_sort, ['cluster1', 'cluster2', 'cluster3', 'cluster4']))
                    df_data[col] = col_transform.map(dic_cluster_sort)
                    
                    range_cluster.loc[col] = [round(np.sort(kmeans.cluster_centers_.ravel())[0],4),
                                            '[{} ~ {}]'.format(round(col_min,4),
                                                               round(np.sort(kmeans.cluster_centers_.ravel())[0:2].mean(),4)),
                                            round(np.sort(kmeans.cluster_centers_.ravel())[1],4),
                                            '({} ~ {}]'.format(round(np.sort(kmeans.cluster_centers_.ravel())[0:2].mean(),4),
                                                               round(np.sort(kmeans.cluster_centers_.ravel())[1:3].mean(),4)),
                                            round(np.sort(kmeans.cluster_centers_.ravel())[2],4),
                                            '({} ~ {}]'.format(round(np.sort(kmeans.cluster_centers_.ravel())[1:3].mean(),4),
                                                               round(np.sort(kmeans.cluster_centers_.ravel())[2:4].mean(),4)),
                                            round(np.sort(kmeans.cluster_centers_.ravel())[3],4),
                                            '({} ~ {}]'.format(round(np.sort(kmeans.cluster_centers_.ravel())[2:4].mean(),4),
                                                               round(col_max,4))]
                self.range_cluster = range_cluster
            ### One-hot emcoding
            onehot_columns_name = df_data.columns[categorical_col | continuous_col]
            df_data = pd.get_dummies(df_data, columns = onehot_columns_name)
            
        return df_data
    
    def FeatureSelection(self, df_data_NG):
        """
        Use the Apriori to select feature.
        According to the result of Apriori,
        collect the consequents of association rules of y as key feature
        and record in self.key_feature.
        
        Parameters
        -----
        df_data : dataframe(pandas)
            The data after pre-processing.
        """
        y_NG = df_data_NG[self.y_col]
        df_data_NG = df_data_NG.drop(self.y_col, axis=1)
        
        list_start = [i for i in range(0, df_data_NG.shape[1]+1, self.check_size)]
        
        key_feature = set([])
        for start in list_start:
            end = min(start + self.check_size, df_data_NG.shape[1]+1)
            
            ### Partition the feature
            df_data_part = pd.concat([y_NG, df_data_NG.iloc[:,start:end]], axis=1)
            
            ### Do the Apriori.
            y_rules = self.Apriori_AntecedentIsY(df_data_part)
            
            ### Union all 'consequents'.
            for index in y_rules.index:
                key_feature = key_feature.union(y_rules['consequents'].loc[index])
        self.key_feature = list(key_feature)
        
    def Apriori_AntecedentIsY(self, df_data):
        """
        Do the Apriori according to min_support, min_confidence, and min_lift.
        
        Parameters
        -----
        df_data : dataframe(pandas)
            The data after pre-processing.
        
        Returns
        -----
        y_rules : dataframe(pandas)
            The association rules of df_data.
        """
        ### Create the frequent itemsets from apriori.
        frequent_itemsets = apriori(df_data,
                                    min_support = self.min_support,
                                    use_colnames = True)
        
        ### Use min_lift to select the rules.
        rules_lift = association_rules(frequent_itemsets,
                                       metric = "lift",
                                       min_threshold = self.min_lift)
        # rules_lift.to_csv(r"C:\Users\JoyWCLi\rules_lift.csv")
        ### Use min_confidence to select the rules 
        ### and choose the reles with 'antecedents' == y.
        y_rules = rules_lift[(rules_lift['confidence'] >= self.min_confidence) &
                             (rules_lift['antecedents'] == {self.y_col})]
        return y_rules
    
    def run(self, df_data, y_col, Input_categorical_col=[]):
        """
        First, use the function FeatureSelection to select the key feature.
        Second, perform Apriori based on the result of feature selection.
        If there are too many key features, only self.key_feature will be returned.
        
        Parameters
        -----
        df_data : dataframe(pandas)
            The data after pre-processing.
        y_col : str
            The colume of y in df_data.
        Input_categorical_col: list
            list of categorical columns.
        
        Returns
        -----
        y_rules : dataframe(pandas)
            The association rules of df_data.
        self.key_feature : list
            The key feature from function FeatureSelection.
            *It will ONLY be returned if there are too many key features*
        """
        self.df_data = df_data
        self.y_col = y_col
        
        ### Do the one hot encoding
        df_data_OneHot = self.OneHot(self.df_data, Input_categorical_col)
        # df_data_OneHot.to_csv(r"D:\Pycaret\MMFA會議\關聯性分析\df_data_OneHot.csv")
        
        ### Select the sample data with y == 1
        df_data_NG = df_data_OneHot[df_data_OneHot[self.y_col] == 1].reset_index(drop=True) 
        
        ### Feature selection
        self.FeatureSelection(df_data_NG)
        
        if len(self.key_feature) < self.check_size:
            key_feature_y = self.key_feature + [self.y_col]
            df_data_NG = df_data_NG[key_feature_y]
            
            ### Do the Apriori.
            y_rules = self.Apriori_AntecedentIsY(df_data_NG)
            
            ### Sort rules.
            y_rules = y_rules.sort_values(by='confidence', ascending = False)
            y_rules = y_rules.reset_index(drop=True)
            y_rules_df = y_rules.copy()
            
            ### For json
            ### You can get dataframe when you comment out this line.
            y_rules = y_rules.to_dict(orient='records')
            
            return y_rules,  y_rules_df
        else:
            ### Return key_feature when len of key_feature greater then check_size.
            
            print("key_feature greater than check_size.")
            return self.key_feature, ""




# #==========================================================
# ## If you want to try, it can help you.
# # import Association_rules_Apriori as apr

# # Sample data
# df_data = pd.read_excel(r'D:\Pycaret\MMFA會議\關聯性分析\宗翰\bktest\fakedata.xlsx', index_col=[0])
# # df_data = pd.read_csv(r'D:\Pycaret\MMFA會議\關聯性分析\宗翰\credit.csv')
# # For test
# RA = RulesApriori(min_support=0.5, min_confidence=0.5, min_lift=1, check_size=30)
# final, final_df = RA.run(df_data, y_col='y', Input_categorical_col=[])

# # Key feature
# key_feature = RA.key_feature

# # cluster
# cluster = RA.range_cluster
# #==========================================================


