# -*- coding: utf-8 -*-
"""
Created on Fri Jan 21 09:13:10 2022

@author: JoyWCLi

平台呼叫 regression TEST 未知數據
"""

import argparse #承接網頁傳回的參數
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import json
from pycaret.regression import *
import shap
from distutils.util import strtobool
import configparser
import warnings

# 引入 time 模組
import time


def status_change(change_testing_id, update_status):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.testing_model_list SET testing_status='{update_status}' WHERE testing_id='{change_testing_id}';"                 
    cursor.execute(sql)
    #提交修改
    cursor.close()
    db.commit()         
    db.close()

if __name__== "__main__":
    # run block of code and catch warnings
    with warnings.catch_warnings():
    	# ignore all caught warnings
    	warnings.filterwarnings("ignore")
    	# execute code that will generate warnings
   

    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])
    testing_result_data_database = config['testing_result_data_database']['database']

    engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")
    testing_result_data_engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{testing_result_data_database}")
    
    '''input 參數'''
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--testing_id', type=str, default="")
    args = parser.parse_args() 
    testing_id  = args.testing_id #未知測試資料集序號
    
    '''JOY 測試'''
    # testing_id = "220301172904"
    
    
    try:
        
    # =============================================================================
    #    基本參數抓取 
    # =============================================================================
        try:
            #透過資料庫取得參數
            # 查詢語句，選出employee表中的所有數據 
            sql = f''' 
                select * FROM automl_db.testing_model_list WHERE testing_id = '{testing_id}';    
            ''' 
            df = pd.read_sql_query(sql, engine)
            parameter_dict = json.loads(df['parameter_json'][0])  
            model_name = parameter_dict['model_name']
            # model_name = "ada"
            testing_result_path = parameter_dict['testing_result_path']
        
            # 撈取實驗存取 pkl的路徑
            sql_exp = f''' 
                select parameter_json FROM automl_db.model_list WHERE model_number = '{parameter_dict['experiment_number']}';    
            ''' 
            df_exp = pd.read_sql_query(sql_exp, engine)
            exp_parameter_dict = json.loads(df_exp['parameter_json'][0])  
            exp_pkl_path = exp_parameter_dict['experiment_data_path']  
        except Exception as ex_2:
            print(ex_2)
            status_change(testing_id,"fail")
            exit
        
        
    # =============================================================================
    #     抓取testing 資料
    # =============================================================================
        try:
            testing_data_path = parameter_dict['testing_data_path'] 
            web_opid_list = testing_data_path
        
            sub_str = web_opid_list[-3:]
            
            rows = 0
            cols = 0
            testing_data_df = pd.DataFrame()
            if sub_str.lower() == "csv":
                testing_data_df = pd.read_csv(web_opid_list)
                rows = testing_data_df.shape[0]
                cols = testing_data_df.shape[1]
            elif sub_str.lower() == "lsx":
                testing_data_df = pd.read_excel(web_opid_list)
                rows = testing_data_df.shape[0]
                cols = testing_data_df.shape[1]
        except Exception as ex_2:
            print(ex_2)
            status_change(testing_id,"fail")
            exit

    
    
    
    # =============================================================================
    # 載入模型
    # 預測未知數據
    # =============================================================================
        try:
            saved_final_model = load_model(exp_pkl_path + model_name)
            new_prediction = predict_model(saved_final_model, data= testing_data_df)
            
        except Exception as ex_2:
            print(ex_2)
            status_change(testing_id,"fail")
            exit
            
    # =============================================================================
    # 將結果table轉存資料庫 / csv
    # =============================================================================
        try:
            testing_result_path_part1 = testing_result_path.split("automl_upload_testing_result/")[0] + "automl_upload_testing_result/"
            new_prediction.to_excel(testing_result_path_part1 + str(testing_id) + "_result" + ".xlsx", index=False)
            
            # 欄位名稱不允許空格
            new_prediction.columns = new_prediction.columns.str.strip()        

            testing_result_data_con = testing_result_data_engine.connect()
            new_prediction.to_sql(name=str(testing_id), con=testing_result_data_con, if_exists='replace', index=False)
        except Exception:
            pass
        
        status_change(testing_id,"testing OK")
        print("testing OK")
    except Exception as ex_1:
        print(ex_1)
        status_change(testing_id,"fail")
        exit    
