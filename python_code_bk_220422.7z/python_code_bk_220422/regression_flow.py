# -*- coding: utf-8 -*-
"""
Created on Sun Aug 22 13:42:40 2021

@author: JoyWCLi

平台呼叫regression flow
"""

import argparse #承接網頁傳回的參數
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import json
from pycaret.regression import *
import shap
from distutils.util import strtobool
import configparser
import warnings

# 引入自訂的plotly 
from pycaret.regression_plotly import *

# 引入 time 模組
import time

# 開始測量
start = time.process_time()

# 要測量的程式碼
for i in range(10000):
    "-".join(str(n) for n in range(100))


def status_change(change_model_number, update_status):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.model_list SET status='{update_status}' WHERE model_number='{change_model_number}';"                 
                 
    cursor.execute(sql)
    #提交修改
    db.commit()         
    db.close()
    
def plotly_func(file_path):
   
    # 存成json 檔
    div_dic = dict()
    
    try:
        train_path = file_path + "train_residue_df.csv"
        test_path = file_path + "test_residue_df.csv"
        residue_plotly_div, residue_plotly_script = residue_plotly(train_path, test_path, file_path)
        div_dic['residue'] = residue_plotly_div
        div_dic['residue_script'] = residue_plotly_script

    except Exception:
        div_dic['residue'] = "fail"
        div_dic['residue_script'] = ""
    
    try:
        vc_path = file_path + "Validation Curve.csv"
        validation_plotly_div, validation_plotly_script = validation_plotly(vc_path, file_path)
        div_dic['validation'] = validation_plotly_div
        div_dic['validation_script'] = validation_plotly_script
    except Exception:
        div_dic['validation'] = "fail"
        div_dic['validation_script'] = ""
    
    
    try:
        fi_path = file_path + "Feature Importance (All).csv"
        feature_importance_plotly_div, feature_importance_plotly_script = feature_importance_plotly(fi_path, file_path)
        div_dic['feature_importance'] = feature_importance_plotly_div
        div_dic['feature_importance_script'] = feature_importance_plotly_script
    except Exception as e:
        print(e)
        div_dic['feature_importance'] = "fail"
        div_dic['feature_importance_script'] = ""
    
    try:
        data_path = file_path + "Learning Curve.csv"
        learning_curve_plotly_div, learning_curve_plotly_script = learning_curve_plotly(data_path, file_path)    
        div_dic['learning_curve'] = learning_curve_plotly_div
        div_dic['learning_curve_script'] = learning_curve_plotly_script
    except Exception:
        div_dic['learning_curve'] = "fail"
        div_dic['learning_curve_script'] = ""
    
    try:
        data_path = file_path + "Cook Distance.csv"
        thresh_path = file_path + "Cook Distance_influence_thresh_outlierP.csv"
        cooks_plotly_div, cooks_plotly_script = cooks_plotly(data_path, thresh_path, file_path)    
        div_dic['cook_distance'] = cooks_plotly_div
        div_dic['cook_distance_script'] = cooks_plotly_script
    except Exception:
        div_dic['cook_distance'] = "fail"
        div_dic['cook_distance_script'] = ""
    
    try:        
        data_path = file_path + "manifold.csv"
        manifold_plotly_div, manifold_plotly_script = manifold_plotly(data_path, file_path)
        div_dic['manifold'] = manifold_plotly_div
        div_dic['manifold_script'] = manifold_plotly_script
    except Exception:
        div_dic['manifold'] = "fail"
        div_dic['manifold_script'] = ""
    # div_df = pd.DataFrame.from_dict(div_dic, orient='index').rename(columns={0:'json'})
    return div_dic




if __name__== "__main__":
    # run block of code and catch warnings
    with warnings.catch_warnings():
    	# ignore all caught warnings
    	warnings.filterwarnings("ignore")
    	# execute code that will generate warnings
   

    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")
    
    '''input 參數'''
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--model_number', type=str, default="")
    parser.add_argument('--train_db_number', type=str, default="")
    args = parser.parse_args() 
    model_number  = args.model_number #模型序號
    train_db_number  = args.train_db_number #訓練資料集序號
    
    '''JOY 測試'''
    # model_number = "220317160310"
    # train_db_number = "220317155016"
    
# =============================================================================
#    基本參數抓取 
# =============================================================================
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.model_list SET status='start_python' WHERE model_number='{model_number}';"                 
    cursor.execute(sql)
    #提交修改
    db.commit()         
    db.close()

    #透過資料庫取得參數
    # 查詢語句，選出employee表中的所有數據 
    sql = f''' 
        select * FROM automl_db.model_list WHERE model_number = '{model_number}';    
    ''' 
    df = pd.read_sql_query(sql, engine)
    parameter_dict = json.loads(df['parameter_json_spe'][0])    
    
# =============================================================================
#     SETUP
# =============================================================================
    try:
                
        # =============================================================================
        #     取得train / test 資料
        # =============================================================================
        # 查詢語句，選出train表中的所有數據 
        sql = f''' 
            select * FROM automl_file_db.`{train_db_number}`;    
        ''' 
        train_file_db = pd.read_sql_query(sql, engine)            
        
        #定義數值型欄位
        num_list = parameter_dict['numeric_column_list_str']
        #定義類別型欄位
        cat_list = parameter_dict['categorical_column_list_str']
        # 定義忽略不使用的欄位
        ignore_list = parameter_dict['remove_column_list']
        
        data = train_file_db.copy()
        # 移除重複資料及全空欄位
        if parameter_dict['remove_duplicate_empty_bool'] == 'True':
            import pycaret.preprocess_eda as preprocess_eda
            data = train_file_db.copy()
            data, len_data_duplicated = preprocess_eda.duplicate(data, parameter_dict['target'])
            data, empty_all_column_remove_list = preprocess_eda.missing_value(data, parameter_dict['target'])  
        else:
            empty_all_column_remove_list = []
            
        # 將 欲忽略不使用的欄位 與 全空欄位合併，並確保target欄位不再其中
        ignore_list = ignore_list + empty_all_column_remove_list
        ignore_list  = [ignore_list_x for ignore_list_x in ignore_list if ignore_list_x != parameter_dict['target']] 
        ignore_list = set(ignore_list)
        ignore_list = list(ignore_list)
        
        # 抓取test資料
        if parameter_dict['test_db_number'] != '請選擇':
            # 查詢語句，選出test表中的所有數據 
            sql = f''' 
                select * FROM automl_file_db.`{parameter_dict['test_db_number']}`;    
            ''' 
            test_file_db = pd.read_sql_query(sql, engine)
        else:
            test_file_db = None
            
        # =============================================================================
        #     參數轉換
        # =============================================================================
        polynomial_features_bool = False
        trigonometry_features_bool = False
        feature_interaction_bool = False
        
        if parameter_dict['feature_polynomial_method'] == 'noneed':
            polynomial_features_bool = False
            trigonometry_features_bool = False
            feature_interaction_bool = False
            
        elif  parameter_dict['feature_polynomial_method'] == 'system_auto':
            polynomial_features_bool = False
            trigonometry_features_bool = False
            feature_interaction_bool = True
    
        else:
            polynomial_features_bool = False   
            
        if parameter_dict['exclude_model_list'][0] == "":
            parameter_dict['exclude_model_list'] = None
            
        if parameter_dict['model_list'][0] == "":
            parameter_dict['model_list'] = None
            
        if parameter_dict['combine_rare_levels_bool'] == "False":
            parameter_dict['rare_level_threshold_number'] = 0
               
        # =============================================================================
        #   開始setup
        # =============================================================================

        clf2 = setup(data = data.iloc[:,:], #資料集
                     n_jobs=8,
                      target = parameter_dict['target'], #目標欄位
                      train_size = 0.8, #訓練資料集比例
                      test_data = test_file_db,
                       categorical_features=cat_list, #綁訂類別行欄位
                      high_cardinality_features = parameter_dict['cardinal_encoding_list'], #當分類特徵包含多個級別時，可以使用此參數將其壓縮為更少的級別
                      numeric_features = num_list, #綁訂數值型欄位
                      date_features =  parameter_dict['datetime_column_list_str'], #綁定時間型欄位
                      ignore_features =  ignore_list, #欲忽略欄位
                      normalize = eval(parameter_dict['feature_normalize_bool']), #是否要normalize
                      normalize_method = parameter_dict['feature_normalize_method'],  #normalize 方法
                      transformation = eval(parameter_dict['feature_transform_bool']), #是否要transform
                      transformation_method = parameter_dict['feature_transform_method'],  #transform 方法
                      pca = eval(parameter_dict['pca_bool']), #是否要 PCA
                      pca_method = parameter_dict['pca_method'], #pca 方法
                      pca_components = int(parameter_dict['pca_remain_percent']), #pca保留比例
                      bin_numeric_features = parameter_dict['bin_numeric_list'], #要將數字特徵轉換為分類特徵
                      remove_outliers = eval(parameter_dict['remove_outlier_bool']), #移除離群值
                      outliers_threshold = float(parameter_dict['outlier_thred_number']), #離群值離群比例   
                      create_clusters = eval(parameter_dict['cluster_bool']), #加入分群特徵 (為true,會造成CPU過高)
                      cluster_iter = int(parameter_dict['cluster_iterate_number']), #分群迭帶次數  
                      polynomial_features = polynomial_features_bool, #是否由系統將特徵ploynomial sin cos tan power
                      trigonometry_features = trigonometry_features_bool, #是否由系統將特徵trigonometry
                      feature_selection = eval(parameter_dict['feature_selection_bool']), #特徵篩選!
                      feature_method_overlap_number = int(parameter_dict['overlap_threshold']), #最少幾個演算法重疊才選取該特徵                 
                      feature_interaction = feature_interaction_bool, #是否由特徵 + - * /
                      transform_target =  eval(parameter_dict['target_transform_bool']), #是否將target進行特徵轉換
                      transform_target_method = parameter_dict['target_transform_method'], #target轉換方法
                      data_split_shuffle = True, #在train test split時，是否進行資料洗牌
                      data_split_stratify = False, #在“train_test_split”期間控制分層。設置為 True 時，將按目標列分層。要在任何其他列上分層，請傳遞列名列表。當data_split_shuffle為 False時忽略
                      fold_strategy = parameter_dict['cross_validation_method'], #交叉驗證的方法
                      fold = int(parameter_dict['cross_validation_number']), #交叉驗證數量
                      session_id = int(parameter_dict['random_seed']), #random_seed
                      combine_rare_levels = eval(parameter_dict['combine_rare_levels_bool']), #低於特定閾值的分類特徵中級別的頻率百分位數將組合成一個級別。
                      rare_level_threshold = float(parameter_dict['rare_level_threshold_number']), #低於特定閾值的分類特徵中級別的頻率百分位數將組合成一個級別。
                      ignore_low_variance = eval(parameter_dict['ignore_low_variance_bool']), #移除低方差特徵
                      remove_perfect_collinearity = eval(parameter_dict['remove_multicollinearity_bool']), #移除兩兩特徵具有高度共線性之特徵
                      # remove_multicollinearity = eval(parameter_dict['remove_multicollinearity_bool']), #移除兩兩特徵具有高度共線性之特徵 位加入!
                      # multicollinearity_threshold = float(parameter_dict['multicollinearity_threshold_number']), #共線性閥值 位加入!
                      
                      # imputation_type = "simple", 補植方法尚未加入!
                      # iterative_imputation_iters：int 未加入!
                      # categorical_imputation：str 未加入!
                      # categorical_iterative_imputer：str 未加入!
                      # numeric_imputation：str 未加入!
                      # numeric_iterative_imputer：str 未加入!
                      # handle_unknown_categorical：bool  未加入!
                      # unknown_categorical_method：str 未加入!

                      # remove_perfect_collinearity 未加入!
                      # group_features  未加入!
                      # group_names  未加入!
                      # ordinal_features 將分類特徵編碼為序數 未加入!                      
                      

                      # polynomial_degree  無須加入!
                      # polynomial_threshold  無須加入!
                      # feature_ratio  無須加入!
                      # fold_groups   無須加入!                                         
    
                      # numeric_imputation='interpolation', #補值方法    
                    )
        # setup_df = pull()
        
        # 儲存train_data test_data
        X_train_down = get_config("X_train")
        y_train_down = get_config("y_train")
        X_test_down = get_config("X_test")
        y_test_down = get_config("y_test")
        
        '''儲存需要的產出的資訊'''
        tmp_prep_pipe = get_config("prep_pipe")
        
        # 低方差的特徵
        low_variance_feature_list = []        
        try:
            low_variance_feature_list = list(tmp_prep_pipe.named_steps.znz.to_drop)
        except Exception:
            print("fail to save pipe ")
            
        # 完美共線性的特徵
        fix_perfect_feature_list = []        
        try:
            fix_perfect_feature_list = list(tmp_prep_pipe.named_steps.fix_perfect.columns_to_drop)
        except Exception:
            print("fail to save pipe ")


        try:
            X_y_train_down = pd.merge(X_train_down,y_train_down, left_index=True, right_index=True)
            X_y_test_down = pd.merge(X_test_down,y_test_down, left_index=True, right_index=True)
            X_y_train_down.to_csv("transformed_train_dataset.csv")
            X_y_test_down.to_csv("transformed_test_dataset.csv")
        except Exception:
            print("fail to save data")
        
        save_config('myvars.pkl')
        status_change(model_number,'setup_done')        
        print("setup_done")       
        
    except Exception as e:
        status_change(model_number,'setup_fail')        
        print("setup_fail") 
        print(e)

# =============================================================================
# MODEL
# =============================================================================
    def create_blend_model_pkl(multi_select_model, optimize_measure, create_model_fold):
        
        # method_check = "soft"
        # for i in top_select_model:
        #     if str(i)[0:3] == "SVR" or str(i)[0:5] == "Ridge" or str(i)[0:3] == "SVC":
        #         method_check = "hard"
        # print()
        
        create_multi_train_model = blend_models (estimator_list = multi_select_model,
                                                  optimize = optimize_measure,
                                                  fold = create_model_fold, 
                                                  )
        
        multi_model_measure_list = pull()
        final_model = finalize_model(create_multi_train_model)
        save_model(create_multi_train_model, "multi_model" )  
        
        return create_multi_train_model, final_model, multi_model_measure_list       
    
    def create_single_model_pkl(model_name, create_model_fold):
        create_train_model = create_model(model_name, fold=create_model_fold )
        sinlge_model_measure_list = pull()
        final_model = finalize_model(create_train_model)
        save_model(create_train_model, model_name )  
        return create_train_model, final_model, sinlge_model_measure_list  

    def create_plot_model(use_model,save_plot_path):
        '''
        * 'residuals_interactive' - Interactive Residual plots
        * 'residuals' - Residuals Plot
        * 'error' - Prediction Error Plot
        * 'cooks' - Cooks Distance Plot
        * 'rfe' - Recursive Feat. Selection                         
        * 'learning' - Learning Curve
        * 'vc' - Validation Curve
        * 'manifold' - Manifold Learning
        * 'feature' - Feature Importance
        * 'feature_all' - Feature Importance (All)
        * 'parameter' - Model Hyperparameter
        * 'tree' - Decision Tree
        '''
        
        #繪製圖片
        # try:
        #     vc1 =plot_model(use_model,save=True,plot="residuals_interactive",save_path=save_plot_path)
        # except:
        #     print("residuals_interactive fail")
            
        try:
            vc2 =plot_model(use_model,save=True,plot="residuals",save_path=save_plot_path)
        except Exception as e:
            print("residuals fail")
            print(e)
           
        # try:
        #     vc3 =plot_model(use_model,save=True,plot="error",save_path=save_plot_path)
        # except:
        # #     print("error fail")
            
        try:
            vc6 =plot_model(use_model,save=True,plot="cooks",save_path=save_plot_path)
        except Exception as e:
            print("cooks fail")   
            print(e)
           
        try:
            vc1 =plot_model(use_model,save=True,plot="learning",save_path=save_plot_path)
        except Exception as e:
            print("learning fail")
            print(e)
           
        try:
            vc1 =plot_model(use_model,save=True,plot="manifold",save_path=save_plot_path)
        except Exception as e:
            print("manifold fail")
            print(e)
           
        # # try:
        # #     vc1 =plot_model(use_model,save=True,plot="feature",save_path=save_plot_path)
        # # except:
        # #     print("feature fail")
        
        
        #voting model 時無法使用 
        try:
            vc1 =plot_model(use_model,save=True,plot="feature_all",save_path=save_plot_path)
        except Exception as e:
            print("feature_all fail")
            print(e)
        # try:
        #     vc1 =plot_model(use_model,save=True,plot="parameter",save_path=save_plot_path)
        # except:
        #     print("parameter fail")
           
        # try:
        #     vc1 =plot_model(use_model,save=True,plot="vc",save_path=save_plot_path)
        # except Exception as e:
        #     print("vc fail")
        #     print(e)
           
        
        # # try:
        # #     # 先提供DT 模型使用，不然使用時間會過長
        # #     vc1 =plot_model(use_model,save=True,plot="tree",save_path=save_plot_path)
        # # except:
        # #     print("tree fail")
        
        return "plot done"



    train_model_dic = {}         
    final_model_dic = {}
    sinlge_model_measure_dic = {}
    try:
        status_change(model_number,'model_start') #排序的分數
        
        model_match_dic={"Linear Regression" : "lr",
                         "Lasso Regression" : "lasso",
                         "Ridge Regression" : "ridge",
                         "Elastic Net" : "en",
                         "Least Angle Regression" : "lar",
                         "Lasso Least Angle Regression" : "llar",
                         "Orthogonal Matching Pursuit" : "omp",
                         "Bayesian Ridge" : "br",
                         "Automatic Relevance Determination" : "ard",
                         "Passive Aggressive Regressor" : "par",
                         "Random Sample Consensus" : "ransac",
                         "TheilSen Regressor" : "tr",
                         "Huber Regressor" : "huber",
                         "Kernel Ridge" : "kr",
                         "Support Vector Regression" : "svm",
                         "K Neighbors Regressor" : "knn",
                         "Decision Tree Regressor" : "dt",                         
                         "Random Forest Regressor" : "rf",
                         "Extra Trees Regressor" : "et",
                         "AdaBoost Regressor" : "ada",
                         "Gradient Boosting Regressor" : "gbr",
                         "MLP Regressor" : "mlp",
                         "Extreme Gradient Boosting" : "xgboost",
                         "Light Gradient Boosting Machine" : "lightgbm",
                         "CatBoost Regressor" : "catboost"
                         }
        
        tmp_model_list = ['lr','lasso','ridge','en','lar','llar','omp','ard','par','ransac','tr','huber','kr','svm','knn','dt','rf','et','ada','gbr','mlp','xgboost','lightgbm','catboost']

        '''
        # 單一模型建立
        '''
        all_model_plotly_dic_json_srt = ''
        all_model_plotly_dic_json_srt = "{" + all_model_plotly_dic_json_srt

        for x in parameter_dict['model_list']:
        # for x in ['lightgbm']:
            try:
                save_plot_path_tmp = parameter_dict['experiment_data_path'] + "autom_experiment_plot_result/" + x + "/"
                train_model_dic[x], final_model_dic[x], sinlge_model_measure_dic[x] = create_single_model_pkl(x, int(parameter_dict['cross_validation_number']))
                plot_return = create_plot_model(train_model_dic[x], save_plot_path = save_plot_path_tmp)                
                plotly_div_json = plotly_func(save_plot_path_tmp)
                              
                # 將plotly_div_json_str 存入json檔並且放入dictionary 保存
                # import json
                # with open(save_plot_path_tmp + 'plotly_div.json', 'w') as fp:
                #     json.dump(plotly_div_json, fp)  
                    
                div_dic_json = json.dumps(plotly_div_json)                
                
                all_model_plotly_dic_json_srt = all_model_plotly_dic_json_srt + f"\"{x}\":" + div_dic_json.replace("\\" + "\"", "\\" + "'") + ","
                
                tmp_model_list.remove(x)
                tmp_model_list.append(final_model_dic[x])
                
            except Exception as e:
                print(x + "single_model_fail")
                print(e)    
                

        '''
        # 比較模型
        '''
        top_select_model = compare_models(n_select = int(parameter_dict['ensemble_model_number']), #欲選擇的模型數量
                              sort = parameter_dict['model_measure'],
                              # include = parameter_dict['model_list'], 
                              # exclude = parameter_dict['exclude_model_list'], 
                              fold = int(parameter_dict['cross_validation_number']),
                              verbose=True)
        compare_model_list = pull()
        compare_model_list.reset_index(inplace=True)
        compare_model_list["index"] = compare_model_list["Model"].apply(lambda r: model_match_dic[r])        
        compare_model_list['set_model'] = "no"
        compare_model_list['set_model'][compare_model_list['index'].isin(parameter_dict['model_list'])] = "yes"
                
                
        
        '''      
        # 多模型建立
        '''
        try:
            if (len(parameter_dict['model_list']) < int(parameter_dict['ensemble_model_number'])) or (int(parameter_dict['ensemble_model_number']) == 0):
                multi_use_mode_list = top_select_model
            else:
                print("打")
                multi_use_mode_list = []
                select_set_model_list = compare_model_list[compare_model_list['set_model'] == 'yes']['index'].to_list()[:int(parameter_dict['ensemble_model_number'])]
                for m in select_set_model_list:
                    try:
                        multi_use_mode_list.append(train_model_dic[m])
                    except Exception as e2:
                        print(str(m) + "not in multi_model")

                        
            multi_blend_model, final_multi_blend_model, multi_model_measure_list = create_blend_model_pkl(  multi_use_mode_list,
                                                                                                            parameter_dict['model_measure'],
                                                                                                            int(parameter_dict['cross_validation_number']),
                                                                                                            )
            plot_return = create_plot_model(multi_blend_model,save_plot_path=parameter_dict['experiment_data_path'] + "autom_experiment_plot_result/multi_model/")   
            plotly_div_json = plotly_func(parameter_dict['experiment_data_path'] + "autom_experiment_plot_result/multi_model/")
            div_dic_json = json.dumps(plotly_div_json)  
            all_model_plotly_dic_json_srt = all_model_plotly_dic_json_srt + "\"voting\":" + div_dic_json.replace("\\" + "\"", "\\" + "'") + ","
            
        except Exception as e:
            print("multi_model_fail")
            print(e)                
                
            
        all_model_plotly_dic_json_srt = str(all_model_plotly_dic_json_srt[:-1] + "}" )
        
        
        # 將voting 的結果寫進入所有model的比較表中
        try:                
            voting_model_list = ", ".join(pd.DataFrame(multi_blend_model.estimators).iloc[:,0].to_list())
            multi_model_measure_list['index'] = "voting"
            multi_model_measure_list['Model'] = voting_model_list
            multi_model_measure_list['TT (Sec)'] = 999
            multi_model_measure_list['set_model'] = "yes"
            SD_df = multi_model_measure_list.loc["Mean"]
            frames = [compare_model_list, pd.DataFrame(SD_df).T]
            compare_model_list_voting = pd.concat(frames)            
            compare_model_list_js = compare_model_list_voting.to_json(orient = 'records')
            
            
        except Exception as e:
            compare_model_list_js = compare_model_list.to_json(orient = 'records')
            print("multi_model_measure fail to sql.")
            print(e)
            
        try:                
            # 將保存的compare_model_list_js 全存入資料庫
            #資料庫連線設定
            db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
            #建立操作游標
            cursor = db.cursor()
            #SQL語法
            sql = " UPDATE automl_db.model_list SET compare_model_json='" + compare_model_list_js + f"' WHERE model_number='{model_number}';"  
            # sql = " UPDATE automl_db.model_list SET model_score='12' WHERE model_number='210904221939';"                 
            cursor.execute(sql)
            #提交修改
            db.commit()         
            db.close()        
        except Exception as e:        
            print("compare model dataframe to mysql fail.")
            print(e)
              
        try:                
            # 將保存的plotly div json 全存入資料庫
            #資料庫連線設定
            db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
            #建立操作游標
            cursor = db.cursor()
            #SQL語法
            sql = " UPDATE automl_db.model_list SET plotly_json='" + all_model_plotly_dic_json_srt + f"' WHERE model_number='{model_number}';"  
            # sql = " UPDATE automl_db.model_list SET model_score='12' WHERE model_number='210904221939';"                 
            cursor.execute(sql)
            #提交修改
            db.commit()         
            db.close()
        except Exception as e:        
            print("plotly to mysql fail.")
            print(e)            
            
        status_change(model_number,'model_done')
            
        
        # 建立模型
        print("model_done")

    except Exception as e:
        # compare
        status_change(model_number,'model_fail')
        print(e)
        print("model_fail")

# 結束測量
end = time.process_time()

# 輸出結果
print("執行時間：%f 秒" % (end - start))
# # =============================================================================
# # 載入模型
# # 預測未知數據
# # =============================================================================
    # saved_final_lightgbm = load_model('myvars')
#     new_prediction = predict_model(saved_final_lightgbm, data=train_file_db.iloc[-100:,:])
#     new_prediction.head()

    
        