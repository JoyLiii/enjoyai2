# -*- coding: utf-8 -*-
"""
Created on Fri Sep 24 13:48:12 2021

@author: JoyWCLi

執行regression model 的 解釋模型繪製
"""

import argparse #承接網頁傳回的參數
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import json
import shap
from distutils.util import strtobool
import configparser
import warnings

from pycaret.regression import *
from pycaret.regression import load_model

def status_change(change_model_number, update_status):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.shap_list SET plot_status='{update_status}' WHERE shap_id='{change_model_number}';"                 
    cursor.execute(sql)
    #提交修改
    cursor.close()
    db.commit()         
    db.close()
    
def use_explain_model(input_model_pkl_name, plot_name, assign_feature = None):
    # shap.initjs()
     shap_plot, shap_plot_div, shap_plot_script, shap_html_path = interpret_model(input_model_pkl_name,
                       # X_new_sample=x_tt, 輸入測試檔
                       save=True,
                       plot = plot_name,
                       feature = assign_feature,
                       # X_tmp_train=get_config("X_train"),
                      )
     return  shap_plot, shap_plot_div, shap_plot_script, shap_html_path 

def png_to_base64_div_script(png_path_str):
    from base64 import b64encode
    # png_path_str = "C:\\inetpub\\wwwroot\\AutoML\\AutoML_user_file\\automl_experiment_file\\210918171853\\SHAP correlation_test_ipa_num_ipa_y.png"
    # 讀取圖片檔案
    fp = open(png_path_str, 'rb')
    img = fp.read()
    fp.close()
    base64_bytes = b64encode(img)
    base64_string = base64_bytes.decode('utf8')
    
    # 在網頁上呈現必須加入
    base64_string = "data:image/png;base64, " + base64_string
    
    # json_str = '{"plot":"' + base64_string + '"}'

    print("============")
    print("Done! ")
    
    return base64_string
    

if __name__== "__main__":
    # run block of code and catch warnings
    with warnings.catch_warnings():
    	# ignore all caught warnings
    	warnings.filterwarnings("ignore")
    	# execute code that will generate warnings
   

    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")
    
    '''input 參數'''
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--shap_number', type=str, default="")
    parser.add_argument('--model_number', type=str, default="")
    parser.add_argument('--config_pkl_name', type=str, default="")
    parser.add_argument('--model_pkl_name', type=str, default="")
    args = parser.parse_args() 
    i_shap_number = args.shap_number #shap序號
    i_model_number  = args.model_number #模型序號
    i_config_pkl_name  = args.config_pkl_name #setup config 檔案
    i_model_pkl_name  = args.model_pkl_name #執行的模型pkl名稱
    if i_model_pkl_name == "voting":
        i_model_pkl_name = "multi_model"
    

    '''joy test'''
    # =============================================================================
    # i_model_number = 220303135239
    # i_config_pkl_name = r"D:\joy\web\AutoML_user_file\automl_experiment_file\220303135239\myvars.pkl"
    # i_model_pkl_name = r"D:\joy\web\AutoML_user_file\automl_experiment_file\220303135239\br"
    # i_shap_number = "220303143428"
    # =============================================================================

    
    # 載入模型初始設定, 以便寫入資料庫
    sql = f''' 
        select model_name, 
        train_dataset, 
        test_dataset, 
        JSON_UNQUOTE(JSON_EXTRACT(parameter_json, '$.cross_validation_number')) as n_fold , 
        JSON_UNQUOTE(JSON_EXTRACT(parameter_json, '$.feature_normalize_bool')) as normal_bool, 
        JSON_UNQUOTE(JSON_EXTRACT(parameter_json, '$.feature_normalize_method')) as normal_method 
        FROM automl_db.model_list WHERE model_number = '{i_model_number}';    
    ''' 
    model_setup_json = pd.read_sql_query(sql, engine)   
    if str(model_setup_json["normal_bool"][0]) == "True":
        normal_method = str(model_setup_json["normal_method"][0])
    else:
        normal_method = "False"        
    
    # 載入setup 資訊
    load_config(i_config_pkl_name)
    saved_model = load_model(i_model_pkl_name)
    shapo_use_model = saved_model.steps[len(saved_model.steps) - 1][1]
    
    # 將資料新增入 shap_list
    try:
        tmp_sql_model_name = str(model_setup_json["model_name"][0])
        tmp_sql_n_fold = str(model_setup_json["n_fold"][0])        
        feature_list_json = '{"feature_list":"' + "% &".join(list(get_config("X_train").columns)) + '"}'
        
        # 將保存的plotly div json 全存入資料庫
        #資料庫連線設定
        db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
        #建立操作游標
        cursor = db.cursor()
        #SQL語法
        sql = f"UPDATE automl_db.shap_list SET experiment_name='{tmp_sql_model_name}', testing_data='testing data from setup', n_fold='{tmp_sql_n_fold}', training_feature_list='{feature_list_json}', feature_set='{normal_method}', plot_status='start shap' WHERE shap_id='{i_shap_number}';"

        cursor.execute(sql)
        db.commit()
        cursor.close()
        db.close()         
    except Exception as e:        
        # 將保存的plotly div json 全存入資料庫
        #資料庫連線設定
        db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
        #建立操作游標
        cursor = db.cursor()
        #SQL語法
        sql = f"UPDATE automl_db.shap_list plot_status='fail to start' WHERE shap_id='{i_shap_number}';"

        cursor.execute(sql)
        db.commit()
        cursor.close()
        db.close() 
        
        print("fail to starting shap")
        print(e)
    
    
    try:
        # # 繪製interpret model，保存json
        summary_shap_str = '{'
        reason_shap_str = '{'
        corr_shap_str = '{'
        msa_shap_str = '{'
        pfi_shap_str = '{'
        pdp_shap_str = ''
    
        # =============================================================================
        #     '''
        #     * 使用summary_html_path圖片路徑，轉換後，寫進資料庫 
        #     
        #     '''   
        # =============================================================================
        
        try:
            summary_plot, summary_plot_div, summary_plot_script, summary_html_path = use_explain_model(shapo_use_model,"summary")
            tmp_summary_base64 = png_to_base64_div_script(summary_html_path)
            summary_shap_str = summary_shap_str + "\"png_path\":" + "\"" +  summary_html_path + "\","
            summary_shap_str = summary_shap_str + "\"png_str\":" + "\"" + tmp_summary_base64 + "\""
            print("summary done")
        except Exception:
            print("summary fail")

        
        # =============================================================================
        #     '''
        #     * reason_plot_div 紀錄 html的 div 字串
        #     * reason_plot_script  紀錄 html的 script 字串
        #     * reason_html_path 紀錄 html的 路徑 字串    
        #     '''
        # =============================================================================

        try:
            reason_plot, reason_plot_div, reason_plot_script, reason_html_path = use_explain_model(shapo_use_model,"reason")
            reason_plot_div = reason_plot_div.replace('"',"'")
            reason_plot_div = reason_plot_div.replace( "'", "\\" + "'")
            reason_plot_script = reason_plot_script.replace('"',"'")
            reason_plot_script = reason_plot_script.replace( "'", "\\" + "'")
            
            reason_shap_str = reason_shap_str + "\"html_path\":" + "\"" +  reason_html_path + "\","
            reason_shap_str = reason_shap_str + "\"html_div\":" + "\"" +  reason_plot_div.replace("\\" + "\"", "\\" + "'") + "\","
            reason_shap_str = reason_shap_str + "\"html_script\":" + "\"" +  reason_plot_script.replace("\\" + "\"", "\\" + "'") + "\""
            print("reason done")
        except Exception:
            print("reason fail")        
        # =============================================================================
        #     '''
        #     * corr_plot_feature_list 紀錄 所有 feature name的list
        #     * corr_html_path_list 紀錄 所有生成的png 路徑的list
        #     '''
        # =============================================================================
        
        try:
            corr_plot, corr_plot_div, corr_plot_feature_list, corr_html_path_list = use_explain_model(shapo_use_model,"correlation")
            f_count = 0
            for corr_feature_i in corr_plot_feature_list:
                tmp_corr_base64 = png_to_base64_div_script(corr_html_path_list[f_count])
                corr_shap_str = corr_shap_str + f"\"{corr_feature_i}\":" + "\"" +  tmp_corr_base64 + "\","
                f_count = f_count +1
            if len(corr_shap_str) > 1:
                corr_shap_str = corr_shap_str[:-1]
            print("correlation done")  
        except Exception as ex_corr:
            print("correlation fail")  
            print(ex_corr)  
        
        # =============================================================================
        #     '''
        #     * msa_plot_div 紀錄 html的 div 字串
        #     * msa_plot_script  紀錄 html的 script 字串
        #     * msa_html_path 紀錄 html的 路徑 字串    
        #     '''
        # =============================================================================
        try:
            msa_plot, msa_plot_div, msa_plot_script, msa_html_path = use_explain_model(shapo_use_model,"msa")
            msa_plot_div = msa_plot_div.replace('"',"'")
            msa_plot_div = msa_plot_div.replace( "'", "\\" + "'")
            msa_plot_script = msa_plot_script.replace('"',"'")
            msa_plot_script = msa_plot_script.replace( "'", "\\" + "'")
            
            msa_shap_str = msa_shap_str + "\"html_path\":" + "\"" +  msa_html_path + "\","
            msa_shap_str = msa_shap_str + "\"html_div\":" + "\"" +  msa_plot_div.replace("\\" + "\"", "\\" + "'") + "\","
            msa_shap_str = msa_shap_str + "\"html_script\":" + "\"" +  msa_plot_script.replace("\\" + "\"", "\\" + "'") + "\""
            print("msa done")
        except Exception:
            print("msa fail")  
        

    
        # =============================================================================
        #     '''
        #     * pfi_plot_div 紀錄 html的 div 字串
        #     * pfi_plot_script  紀錄 html的 script 字串
        #     * pfi_html_path 紀錄 html的 路徑 字串      
        #     '''
        # =============================================================================
        
        try:
            pfi_plot, pfi_plot_div, pfi_plot_script, pfi_html_path = use_explain_model(shapo_use_model,"pfi")
            pfi_plot_div = pfi_plot_div.replace('"',"'")
            pfi_plot_div = pfi_plot_div.replace( "'", "\\" + "'")
            pfi_plot_script = pfi_plot_script.replace('"',"'")
            pfi_plot_script = pfi_plot_script.replace( "'", "\\" + "'")
            
            pfi_shap_str = pfi_shap_str + "\"html_path\":" + "\"" +  pfi_html_path + "\","
            pfi_shap_str = pfi_shap_str + "\"html_div\":" + "\"" +  pfi_plot_div.replace("\\" + "\"", "\\" + "'") + "\","
            pfi_shap_str = pfi_shap_str + "\"html_script\":" + "\"" +  pfi_plot_script.replace("\\" + "\"", "\\" + "'") + "\""
            print("pfi done")
        except Exception:
            print("pfi fail")
        

    
        # =============================================================================
        #     '''
        #     * pdp_plot_div_script_df 記錄3種資訊
        #     1.["feature"] --> feature name
        #     2.["plot_div"] --> html的 div
        #     3.["plot_script"] --> html的script
        #     
        #     * pdp_html_pathList 紀錄 html的 路徑 字串
        #     '''
        # =============================================================================
        try:
            pdp_plot, pdp_plot_div_script_df, pdp_empty_df, pdp_html_pathList = use_explain_model(shapo_use_model,"pdp")
            tmp_df = pd.DataFrame()
            tmp_df["feature"] = pdp_plot_div_script_df["feature"]
            tmp_df["html_path"] = pdp_html_pathList    
            tmp_df["html_div"] = pdp_plot_div_script_df["plot_div"].str.replace('"', "'")
            tmp_df["html_div"] = tmp_df["html_div"].str.replace( "'", "\\" + "'")
            tmp_df["html_script"] = pdp_plot_div_script_df["plot_script"].str.replace('"',"'")
            tmp_df["html_script"] = tmp_df["html_script"].str.replace( "'", "\\" + "'")
            
            tmp_df_v1 = tmp_df.set_index("feature")
            pdp_shap_str = tmp_df_v1.to_json(orient = 'index')
            pdp_shap_str = pdp_shap_str.replace("\\" + "\\" + "'", "\\" + "'")
            
            print("pdp done")
        except Exception:
            print("pdp fail")
            pdp_shap_str = '{}'
                

        
        summary_shap_str = summary_shap_str + '}'
        reason_shap_str = reason_shap_str + '}'
        corr_shap_str = corr_shap_str + '}'
        msa_shap_str = msa_shap_str + '}'
        pfi_shap_str = pfi_shap_str + '}'
        pdp_shap_str = pdp_shap_str
        
        summary_shap_str = summary_shap_str.replace("\n"," ")
        reason_shap_str = reason_shap_str.replace("\n"," ")
        corr_shap_str = corr_shap_str.replace("\n"," ")
        msa_shap_str = msa_shap_str.replace("\n"," ")
        pfi_shap_str = pfi_shap_str.replace("\n"," ")
        pdp_shap_str = pdp_shap_str.replace("\n"," ") 
        
        
        # =============================================================================
        #     更新shap圖
        # =============================================================================
        
        def update_shap_sql(column_name, shap_json, shap_id): 
            
            '''SQL Server info'''
            config = configparser.ConfigParser()
            config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
            server = config['database']['server']
            DBuser = config['database']['DBuser']
            password = config['database']['password']
            database = config['database']['database']
            port = int(config['database']['port'])
            
            #資料庫連線設定
            db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
            #建立操作游標
            cursor = db.cursor()
            #SQL語法
            sql = f" UPDATE automl_db.shap_list SET {column_name}='{shap_json}' WHERE shap_id='{shap_id}';"                 
            cursor.execute(sql)
            db.commit()         
    
            #提交修改
            cursor.close()
            db.close()       
        
        try:
            update_shap_sql('summary_plot', summary_shap_str, i_shap_number)
        except Exception:
            print("summary_plot fail")
            
        try:
            update_shap_sql('correlation_plot', corr_shap_str, i_shap_number)
        except Exception:
            print("correlation_plot fail")
            
        try:
            update_shap_sql('reason_plot', reason_shap_str, i_shap_number)
        except Exception:
            print("correlation_plot fail")
                   
        try:
            update_shap_sql('msa_plot', msa_shap_str, i_shap_number)
        except Exception:
            print("correlation_plot fail")        
            
        try:
            update_shap_sql('pfi_plot', pfi_shap_str, i_shap_number)    
        except Exception:
            print("correlation_plot fail")           
            
        try:
            update_shap_sql('pdp_plot', pdp_shap_str, i_shap_number)    
        except Exception:
            print("correlation_plot fail")         
        
        status_change(i_shap_number, "shap done")
    except Exception as ex_final:
        status_change(i_shap_number, "shap fail")
        print("shap fail")
        print(ex_final)
        
    

    