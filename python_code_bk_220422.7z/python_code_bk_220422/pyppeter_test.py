# -*- coding: utf-8 -*-
"""
Created on Fri Oct 23 08:48:34 2020

@author: ChunbiZhang
"""

import asyncio
import json
from pyppeteer import launch
from pyppeteer.network_manager import Request
from bs4 import BeautifulSoup
import pandas as pd


async def login(uid, password):
    # 開啟瀏覽器程序.
    browser = await launch({'headless': True , 'args': ['--no-sandbox','--disable-setuid-sandbox',]},executablePath='chrome-win/chrome.exe',ignoreHTTPSErrors=True)
    page = await browser.newPage()
    url = 'http://cimuac:7102/UAC/?UL=http://10.96.48.148:97/main.aspx'
    await page.goto(url)   
    # await page.waitForSelector('#__VIEWSTATE')
    await page.type('#txtInputId', uid)
    await page.type('#txtPassword', password)
#    await page.click('#btn_query')
    await asyncio.sleep(3)
    # 鼠标模拟点击（类似于毫无目的的在屏幕上点击，迷惑对方）
    page.mouse
    # 点击提交，并等待页面正确响应。
    await asyncio.gather(
      page.click("#ext-gen22"),
      page.waitForNavigation(),
    )
                     
    # await page.waitForSelector('#WMA_Table')
    # await page.goto('view-source:http://l6am0-srv1.corpnet.auo.com/AR/MQC_RECORD/Etch_Rate/Etch_Rate_Record.aspx')   
#    html_doc = await page.content()
    html_doc = await page.plainText()
    await browser.close()
    return html_doc


uid = 'joywcli' #NT帳號
password = 'Auo+01288' #NT密碼

asyncio.set_event_loop(asyncio.new_event_loop())
html_doc = asyncio.get_event_loop().run_until_complete(login(uid,password))
#soup = BeautifulSoup(html_doc, 'lxml')
#table = soup.select('.table')
df = pd.read_html(html_doc)
print(df)

