# -*- coding: utf-8 -*-
"""
Created on Wed Oct 20 16:43:00 2021

@author: joywcli
"""
import os
os.environ['NUMEXPR_MAX_THREADS'] = '16'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import argparse #承接網頁傳回的參數
import configparser
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import json
from distutils.util import strtobool
import configparser
import warnings

import numpy as np
import pandas as pd
import optimization_pso as opt_class

def status_change(change_number, update_status):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.para_recommend_list SET recommend_status='{update_status}' WHERE recommend_id='{change_number}';"                 
    cursor.execute(sql)
    #提交修改
    cursor.close()
    db.commit()         
    db.close()
    
def result_change(change_number, update_result):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.para_recommend_list SET recommend_result='{update_result}' WHERE recommend_id='{change_number}';"                 
    cursor.execute(sql)
    #提交修改
    cursor.close()
    db.commit()         
    db.close()    
    

def get_data_and_category_feature(i_dataset_number, target):   
        
    sql = f''' 
        select * FROM automl_file_db.`{i_dataset_number}`;    
    ''' 
    train_file_db = pd.read_sql_query(sql, engine) 
    
    sql = f''' 
        select variable, logType FROM automl_file_detail_db.`{i_dataset_number}`;    
    ''' 
    type_df = pd.read_sql_query(sql, engine)     
    

    cate_list = list(type_df[type_df["logType"] == 'Categorical']["variable"])
    drop_list = list(type_df[(type_df["logType"] != 'Categorical') & (type_df["logType"] != 'Numeric')]["variable"])
    target_col_type = type_df[type_df["variable"] == target]["logType"].values[0]
    
    return train_file_db, cate_list, drop_list, target_col_type
    
    
if __name__== "__main__":
    
    parent_id = os.getpid()
    print(parent_id)
    
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")    
    
    '''input 參數'''
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--para_recommend_number', type=str, default="")
    parser.add_argument('--dataset_number', type=str, default="")
    # parser.add_argument('--target', type=str, default="")
    # # parser.add_argument('--model_type', type=str, default="")
    # parser.add_argument('--pos_neg_label', type=str, default="")
    # parser.add_argument('--feature_list_json', type=str, default="")
    # parser.add_argument('--better_LS', type=str, default="") 
    
    
    args = parser.parse_args()
    i_para_recommend_number = args.para_recommend_number #參數
    i_dataset_number  = args.dataset_number #參數
    
    '''joy test'''
    # i_para_recommend_number = "2112081839267"
    # i_dataset_number  = "211208183155"
    # 載入模型初始設定, 以便寫入資料庫
    
    sql = f''' 
        select target, class_label_str, feature_list_json, better_LS FROM automl_db.para_recommend_list WHERE recommend_id = '{i_para_recommend_number}';    
        ''' 
    recommend_setup = pd.read_sql_query(sql, engine)       
    
    i_target  = recommend_setup.iloc[0]["target"] #參數
    i_pos_neg_label  = recommend_setup.iloc[0]["class_label_str"] #參數
    i_feature_list_json  = recommend_setup.iloc[0]["feature_list_json"] #參數
    i_better_LS  = recommend_setup.iloc[0]["better_LS"]  #望大或望小 
    
    '''joy test'''
    # i_para_recommend_number = "parameter_test1"
    # # i_dataset_number = "211008100106"
    # i_dataset_number = "210823110618"
    # i_target = "class0"
    # # i_model_type = "classify"  #classify / regression
    # i_pos_neg_label = ""
    # i_feature_list_json = "" 
    i_better_LS = "small" #預設望小
    
    status_change(i_para_recommend_number,"start recommend python")
    try:
        # =============================================================================
        #   二元分類型target 轉換label 尚未處理
        # =============================================================================
        
        
        
        # =============================================================================
        #     預設最佳化是望小
        # =============================================================================
        i_greater = False
        
        try:
            if i_better_LS == "large":
                i_greater = True
            else:
                i_greater = False
        except Exception as ex:
            pass
        
        
        # =============================================================================
        #     
        #     # z取得欲使用的資料 以及 類別行欄位
        #     # 根據target 的資料型態 取得 model type 
        # =============================================================================
        
        try:
            use_data, cate_list, drop_list, target_col_type = get_data_and_category_feature(i_dataset_number, i_target)
        except Exception as ex:
            print(ex)
            status_change(i_para_recommend_number,"fail (type 1)")
            exit
        
        i_yInput = 0
        if target_col_type == "Categorical":
            i_yInput = 0
        elif target_col_type == "Numeric":
            i_yInput = 1
            # print("numeric")
              
        # =============================================================================
        #     # 類別型特徵進行 one hot
        # =============================================================================
        
        try:
            if i_yInput == 0:
                cate_list.remove(i_target)
        except Exception:
            pass       


        df_onehot = pd.get_dummies(use_data,columns=cate_list)
        
        # =============================================================================
        #     # 離散的 target 進行minmax壓縮到 0~1 之間
        # =============================================================================
        if i_yInput == 1:
            from sklearn.preprocessing import MinMaxScaler
            scaler = MinMaxScaler()
            df_onehot[i_target] = scaler.fit_transform(pd.DataFrame(df_onehot[i_target]))
        data_frame = df_onehot.copy()    
        
        # =============================================================================
        #     # 生成特徵list
        #     # 將以處理過的data取得其column名稱，變成list的形式
        #     # 並移除 target、非類別及離散型的特徵
        # =============================================================================
        key_feature_all = data_frame.columns.to_list()
        key_feature_all.remove(i_target)
        for i in drop_list:
            # print(i)
            key_feature_all.remove(i)
            
                    
        # =============================================================================
        #           刪除target欄位中 為空的資料  
        # =============================================================================
        data_frame.dropna(subset=[i_target],inplace= True)
        

        # =============================================================================
        #     開始執行PSO
        # =============================================================================
        
        OPT = opt_class.OPT_PSO(all_feature=False,
                          greater=i_greater,
                          yInput=i_yInput,
                          abs_y=False)
        
        final_json, final_df = OPT.run(data_frame=data_frame,
                                key_feature=key_feature_all,
                                y_column_name=i_target)

        
        list_spec = OPT.spec
        list_spec_tmp = list_spec[list_spec["TOP"] == "5%"]
        
        js = list_spec_tmp.to_json(orient = 'records',force_ascii=False)  
        
        # 特殊符號處理
        js = js.replace("'","\\'" )
        
        result_change(i_para_recommend_number,js)

        status_change(i_para_recommend_number,"recommend OK")
        print("recommand OK")    
        
    except Exception as ex_final:
        status_change(i_para_recommend_number,"recommend fail")
        print("recommand fail")
        print(ex_final)
    
        