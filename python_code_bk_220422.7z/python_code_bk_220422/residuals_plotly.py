# -*- coding: utf-8 -*-
"""
Created on Mon Sep  6 16:08:59 2021

@author: JoyWCLi
"""
# joy add
# 將結果直接化成plotly
import plotly
import plotly.express as px
import pandas as pd
from plotly.graph_objs import *


# =============================================================================
# 繪製residues動態圖
# =============================================================================

train = pd.read_csv(r"D:\joy\web\AutoML_web_vb\AutoML_user_file\automl_experiment_file\210904221939\autom_experiment_plot_result\rf\Residualstrain_residue_df.csv")
test  = pd.read_csv(r"D:\joy\web\AutoML_web_vb\AutoML_user_file\automl_experiment_file\210904221939\autom_experiment_plot_result\rf\Residualstest_residue_df.csv")
test['split'] = "test"
db = pd.concat([train,test])
try:

    fig = px.scatter(
        db, x='y_pred', y='residuals',
        marginal_y='violin',
        color='split',
        color_discrete_sequence=[ "blue","green"],
         labels={
             "y_pred": "Predicted Value",
             "residuals": "Residuals",
         },

    )
    fig.update_layout(
        title='Residuals',
    # titlefont=dict(size=22, color='#7f7f7f'), #設定標題名稱、字體大小、顏色
     xaxis=dict(
         title='y_pred',
         # titlefont=dict(size=18),
     ),
     yaxis=dict(
         title='residuals',
         # titlefont=dict(size=18),
     ),
     margin=go.Margin(l=180,r=60,b=50,t=60,pad=0,), #調整圖表的位子
     template= "none", # 變更背景顏色及格線   
    
    
    )
    
    
    # 輸出HTML檔
    plotly.offline.plot(fig, filename='residue.html', auto_open=False,auto_play=False)
    # 輸出DIV 可直接放在網頁上
    plot_div = plotly.offline.plot(fig, include_plotlyjs = False , output_type = 'div')   
    
except Exception as e:
    print(e)
    
    
# =============================================================================
# 繪製validation 動態圖
# =============================================================================

import plotly.graph_objects as go
import numpy as np
vc_df = pd.read_csv(r"D:\joy\web\AutoML_web_vb\AutoML_user_file\automl_experiment_file\210904221939\autom_experiment_plot_result\rf\Validation Curve.csv")


x = vc_df.index.to_list()
x_rev = x[::-1]

# Line 1
y1 = vc_df.train_scores_mean_.to_list()
y1_upper = (vc_df.train_scores_mean_ + vc_df.train_scores_std_).to_list()
y1_lower = (vc_df.train_scores_mean_ - vc_df.train_scores_std_).to_list()
y1_lower = y1_lower[::-1]


# Line 1
y2 = vc_df.test_scores_mean_.to_list()
y2_upper = (vc_df.test_scores_mean_ + vc_df.test_scores_std_).to_list()
y2_lower = (vc_df.test_scores_mean_ - vc_df.test_scores_std_).to_list()
y2_lower = y2_lower[::-1]

#圖表外層設定
layout=go.Layout(
    title='Validation Curve',
    # titlefont=dict(size=22, color='#7f7f7f'), #設定標題名稱、字體大小、顏色
     xaxis=dict(
         title='actual_estimator_max_path',
         # titlefont=dict(size=18),
     ),
     yaxis=dict(
         title='score',
         # titlefont=dict(size=18),
     ),
     margin=go.Margin(l=180,r=60,b=50,t=60,pad=0,), #調整圖表的位子
    template= "none", # 變更背景顏色及格線
)

fig = go.Figure( layout=layout) #將圖層合併
fig.add_trace(go.Scatter(
    x=x+x_rev,
    y=y1_upper+y1_lower,
    fill='toself',
    fillcolor='rgba(0,176,246,0.2)',
    line_color='rgba(255,255,255,0)',
    showlegend=False,
    name='Train',
))
fig.add_trace(go.Scatter(
    x=x+x_rev,
    y=y2_upper+y2_lower,
    fill='toself',

    fillcolor='rgba(0,100,80,0.2)',
    line_color='rgba(255,255,255,0)',
    name='Test',
    showlegend=False,
))

fig.add_trace(go.Scatter(
    x=x, y=y1,
    line_color='rgb(0,176,246)',
    name='Train',
))
fig.add_trace(go.Scatter(
    x=x, y=y2,
    line_color='rgb(0,100,80)',
    name='Test',
))


fig.update_traces(mode='lines+markers')

# 輸出HTML檔
plotly.offline.plot(fig, filename='vc_train_test2.html', auto_open=False,auto_play=False)

# =============================================================================
# 繪製feature importance
# =============================================================================
import plotly.express as px
import plotly.graph_objs as go
import numpy as np

vc_df = pd.read_csv(r"D:\joy\web\AutoML_web_vb\AutoML_user_file\automl_experiment_file\210904221939\autom_experiment_plot_result\rf\Feature Importance (All).csv")

fig = px.bar(vc_df, 
             # titile="Feature Importance",
             x='Value',
             y='Variable',
             orientation='h', #調整成橫向
             animation_frame="Variable",
             )
fig.update_layout(
        title='Feature Importance',
    # titlefont=dict(size=22, color='#7f7f7f'), #設定標題名稱、字體大小、顏色
     xaxis=dict(
         title='actual_estimator_max_path',
         # titlefont=dict(size=18),
     ),
     yaxis=dict(
         title='score',
         # titlefont=dict(size=18),
     ),
      margin=go.Margin(l=180,r=60,b=50,t=60,pad=0,), #調整圖表的位子
    template= "none", # 變更背景顏色及格線
    
    
    
    )
# 輸出HTML檔
plotly.offline.plot(fig, filename='feature_im_train_test2.html', auto_open=False,auto_play=False)






# import plotly.graph_objs as go
# import plotly.offline as py
# vc_df = pd.read_csv(r"D:\joy\web\AutoML_web_vb\AutoML_user_file\automl_experiment_file\210904221939\autom_experiment_plot_result\rf\Feature Importance (All).csv")


# data= [go.Bar(
#         y=vc_df['Variable'], #y軸欄位
#         x=vc_df['Value'], #x軸欄位
#         orientation='h', #調整成橫向
#         text=vc_df['Variable'], #長條圖上標示資料數值
#         textposition = 'auto', #長條圖上標示資料數值的位子，有auto、inside、outside可以做設定
#         #長條圖顏色設定
#         marker=dict(
#         # color='rgb(158,202,225)', #長條圖填滿部分顏色設定
#         # line=dict(color='rgb(8,48,107)'),      
#         size_max=55, range_x=[0,100], range_y=[0,100]
#         ) #長條圖外框顏色設定
# )]
# #圖表外層設定
# layout=go.Layout(
#         title='Feature Importance',
#     # titlefont=dict(size=22, color='#7f7f7f'), #設定標題名稱、字體大小、顏色
#      xaxis=dict(
#          title='Variable Importance',
#          # titlefont=dict(size=18),
#      ),
#      yaxis=dict(
#          title='Feature',
#          # titlefont=dict(size=18),
#      ),
#       margin=go.Margin(l=180,r=60,b=50,t=60,pad=0,), #調整圖表的位子
#     template= "none", # 變更背景顏色及格線
# )
# fig = go.Figure(data=data, layout=layout) #將圖層合併
# plotly.offline.plot(fig, filename='bar.html', auto_open=False,auto_play=False)



# =============================================================================
# 繪製cook's距離
# =============================================================================
import plotly
import plotly.express as px
import plotly.graph_objs as go
import numpy as np
db = pd.read_csv(r"D:\joy\web\AutoML_web_vb\AutoML_user_file\automl_experiment_file\210904221939\autom_experiment_plot_result\rf\Cook Distance.csv")

try:

    fig = px.bar(
        db, x='Unnamed: 0', y='0',
         labels={
             "Unnamed: 0": "Predicted Value",
             "0": "Residuals",
         },

    )
    fig.update_layout(
        title='Residuals',
    # titlefont=dict(size=22, color='#7f7f7f'), #設定標題名稱、字體大小、顏色
     xaxis=dict(
         title='y_pred',
         # titlefont=dict(size=18),
     ),
     yaxis=dict(
         title='residuals',
         # titlefont=dict(size=18),
     ),
     margin=go.Margin(l=180,r=60,b=50,t=60,pad=0,), #調整圖表的位子
     template= "none", # 變更背景顏色及格線   
    
    
    )
    
    
    # 輸出HTML檔
    plotly.offline.plot(fig, filename='cook.html', auto_open=False,auto_play=False)
    # 輸出DIV 可直接放在網頁上繪製learning curve
    plot_div = plotly.offline.plot(fig, include_plotlyjs = False , output_type = 'div')   
    
except Exception as e:
    print(e)
    
    
# =============================================================================
# 繪製larning curve
# =============================================================================
import plotly
import plotly.graph_objects as go
import numpy as np
vc_df = pd.read_csv(r"D:\joy\web\AutoML_web_vb\AutoML_user_file\automl_experiment_file\210904221939\autom_experiment_plot_result\rf\Learning Curve.csv")


x = vc_df.x_label.to_list()
x_rev = x[::-1]

# Line 1
y1 = vc_df.train_scores_mean_.to_list()
y1_upper = (vc_df.train_scores_mean_ + vc_df.train_scores_std_).to_list()
y1_lower = (vc_df.train_scores_mean_ - vc_df.train_scores_std_).to_list()
y1_lower = y1_lower[::-1]


# Line 1
y2 = vc_df.test_scores_mean_.to_list()
y2_upper = (vc_df.test_scores_mean_ + vc_df.test_scores_std_).to_list()
y2_lower = (vc_df.test_scores_mean_ - vc_df.test_scores_std_).to_list()
y2_lower = y2_lower[::-1]

#圖表外層設定
layout=go.Layout(
    title='Learning Curve',
    # titlefont=dict(size=22, color='#7f7f7f'), #設定標題名稱、字體大小、顏色
     xaxis=dict(
         title='Training instances',
         # titlefont=dict(size=18),
     ),
     yaxis=dict(
         title='Score',
         # titlefont=dict(size=18),
     ),
     margin=go.Margin(l=180,r=60,b=50,t=60,pad=0,), #調整圖表的位子
    template= "none", # 變更背景顏色及格線
)

fig = go.Figure( layout=layout) #將圖層合併
fig.add_trace(go.Scatter(
    x=x+x_rev,
    y=y1_upper+y1_lower,
    fill='toself',
    fillcolor='rgba(0,176,246,0.2)',
    line_color='rgba(255,255,255,0)',
    showlegend=False,
    name='Train',
))
fig.add_trace(go.Scatter(
    x=x+x_rev,
    y=y2_upper+y2_lower,
    fill='toself',
    fillcolor='rgba(0,100,80,0.2)',
    line_color='rgba(255,255,255,0)',
    name='Test',
    showlegend=False,
))

fig.add_trace(go.Scatter(
    x=x, y=y1,
    line_color='rgb(0,176,246)',
    name='Train',
))
fig.add_trace(go.Scatter(
    x=x, y=y2,
    line_color='rgb(0,100,80)',
    name='Test',
))


fig.update_traces(mode='lines+markers')
# 輸出HTML檔
plotly.offline.plot(fig, filename='Learning Curve.html', auto_open=False,auto_play=False)

# =============================================================================
# 繪製manifold 
# =============================================================================
import plotly
import plotly.graph_objects as go
import plotly.express as px
import numpy as np
vc_df = pd.read_csv(r"D:\joy\web\AutoML_web_vb\AutoML_user_file\automl_experiment_file\210904221939\autom_experiment_plot_result\rf\manifold.csv")


fig = px.scatter(vc_df, x
                 ="X1", 
                 y="X2",
                 color=vc_df.y, 
                 labels={'color': 'y'}
)

fig.update_layout(
    title='Manifold',
# titlefont=dict(size=22, color='#7f7f7f'), #設定標題名稱、字體大小、顏色
 xaxis=dict(
     title='TSNE feature_1',
     # titlefont=dict(size=18),
 ),
 yaxis=dict(
     title='TSNE feature_2',
     # titlefont=dict(size=18),
 ),
 margin=go.Margin(l=180,r=60,b=50,t=60,pad=0,), #調整圖表的位子
 template= "none", # 變更背景顏色及格線   


)
# 輸出HTML檔
plotly.offline.plot(fig, filename='manifold.html', auto_open=False,auto_play=False)








