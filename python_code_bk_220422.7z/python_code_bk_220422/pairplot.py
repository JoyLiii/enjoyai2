# -*- coding: utf-8 -*-
"""
Created on Mon Mar 29 13:57:48 2021

@author: JoyWCLi
"""

import argparse #承接網頁傳回的參數
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import plotly
from profiling_function import *


def get_data(i_dataset_number):
    
    sql = f''' 
        select * FROM automl_file_db.`{i_dataset_number}`;  
    ''' 
    train_file_db = pd.read_sql_query(sql, engine)     
    
    return train_file_db


if __name__== "__main__":
    try:
        '''SQL Server info'''
        config = configparser.ConfigParser()
        config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
        server = config['rule_database']['server']
        DBuser = config['rule_database']['DBuser']
        password = config['rule_database']['password']
        rule_database = config['rule_database']['database']
        database = config['database']['database']
        port = int(config['rule_database']['port'])
    
        engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")    


        # i_dataset = "D:/joy/automl_upload_file/210714160319/20210322_SPTA00_M2_classify.xlsx"
        # i_input1 = "Y" 
        # i_input2 = "AKLowCDAPressure" 
        # i_save_path =  "D:/joy/web/AutoML_web_vb/upload_file_img/210701160123/profiling_data/"
            
        parser = argparse.ArgumentParser(description='')
        parser.add_argument('--datasetNumber', type=str, default="")
        parser.add_argument('--dataset', type=str, default="")
        parser.add_argument('--input1', type=str, default="")
        parser.add_argument('--input2', type=str, default="")
        parser.add_argument('--save_path', type=str, default="")
        args = parser.parse_args()
        i_datasetNumber = args.datasetNumber #參數
        i_dataset = args.dataset #參數
        i_input1  = args.input1 #參數
        i_input2  = args.input2 #參數
        i_save_path  = args.save_path #參數
        
        '''joy test'''
        # i_dataset = r"D:\joy\automl_upload_file\211202185046\enjoyai_diabetes_data_v7_eng.xlsx" #參數
        # i_input1 = "Yield Loss_!!_Numeric"#參數
        # i_input2 = "CM .1_!!_Numeric" #參數
        # i_datasetNumber = 220216142928
        # i_save_path  =  #參數
        
        # 解析input1 input2 的型態
        i_input1_tmp = i_input1.split("_!!_")
        i_input1 = i_input1_tmp[0]
        i_input1_type = i_input1_tmp[1]
        

        i_input2_tmp = i_input2.split("_!!_")
        i_input2 = i_input2_tmp[0]
        i_input2_type = i_input2_tmp[1]        
        
                
        # 將路徑中的\轉換為/img_path
        i_save_path  = i_save_path.replace('\\' , '/') #圖片存放路徑
        
        # web_opid_list = i_dataset
        # web_opid_list = web_opid_list.replace('\\' , '//')
        # # web_opid_list = "D:/joy/automl_upload_file/ALL_WIP_YT.xlsx"
        # sub_str = web_opid_list[-3:]
        
        # web_opid_list_df = pd.DataFrame()
        # if sub_str.lower() == "csv":
        #     web_opid_list_df = pd.read_csv(web_opid_list)
        # elif sub_str.lower() == "lsx":
        #     web_opid_list_df = pd.read_excel(web_opid_list)
    
        web_opid_list_df = get_data(i_datasetNumber)
        # =============================================================================
        #     pairplot輸出動態圖div文字檔，可寫入資料庫存放
        # =============================================================================
        
        # i_input1 = column1
        # i_input2 = column2
        # pairdata = pd.DataFrame([web_opid_list_df[i_input1], web_opid_list_df[i_input2]]).T
        # fig = px.scatter_matrix(pairdata)
        # plotly.offline.plot(fig, filename='pairplot.html')

        
        
        # =============================================================================
        #     兩兩散佈圖
        # =============================================================================
        pairdata = pd.DataFrame([web_opid_list_df[i_input1], web_opid_list_df[i_input2]]).T
        fig = px.scatter_matrix(pairdata)
        # fig.update_layout(hovermode='compare')
    
        # plot_div3 = plotly.offline.plot(fig, include_plotlyjs = False , output_type = 'div')
        fig.update_layout(
            font=dict(
                size=16
            )
        )        
        plotly.offline.plot(fig, filename=i_save_path + 'pairplot.html', auto_open=False,auto_play=False)
        
        # =============================================================================
        #         如兩者皆為  類別資料
        # =============================================================================
        
        if (i_input1_type == "Categorical") and (i_input2_type == "Categorical"):
            
            fig = px.histogram(pairdata, x=i_input2, color=i_input1)
            fig.update_layout(
                font=dict(
                    size=16
                )
            )            
            plotly.offline.plot(fig, filename=i_save_path + 'pairplot2.html', auto_open=False,auto_play=False)
        
        # =============================================================================
        #         如一者為類別 一者為連續
        # =============================================================================
        if ((i_input1_type == "Categorical") and (i_input2_type == "Numeric")) :
        
            fig = px.box(web_opid_list_df, x=i_input1, y=i_input2)  
            fig.update_layout(
                font=dict(
                    size=16
                )
            )            
            plotly.offline.plot(fig, filename=i_save_path + 'pairplot2.html', auto_open=False,auto_play=False)
            
        if ((i_input1_type == "Numeric") and (i_input2_type == "Categorical")) :
        
            fig = px.box(web_opid_list_df, x=i_input2, y=i_input1)  
            fig.update_layout(
                font=dict(
                    size=16
                )
            )
            plotly.offline.plot(fig, filename=i_save_path + 'pairplot2.html', auto_open=False,auto_play=False)
        
        print('success')
    except Except as ex:
        print(ex)
        print("fale")
    


