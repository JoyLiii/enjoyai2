# -*- coding: utf-8 -*-
"""
Created on Tue Jan  4 10:24:09 2022

@author: joywcli

重組資料
"""
import os
os.environ['NUMEXPR_MAX_THREADS'] = '16'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import argparse #承接網頁傳回的參數
import configparser
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import json
from distutils.util import strtobool
import configparser
import warnings

import numpy as np
import pandas as pd

from sklearn.preprocessing import KBinsDiscretizer
from row_col import *
   

def status_change(change_number, update_status):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['transform_data_database']['server']
    DBuser = config['transform_data_database']['DBuser']
    password = config['transform_data_database']['password']
    database = config['transform_data_database']['database']
    port = int(config['transform_data_database']['port'])

    
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.transformed_dataset_info SET transformed_dataset_status='{update_status}' WHERE transformed_dataset_number='{change_number}';"                 
    cursor.execute(sql)
    #提交修改
    cursor.close()
    db.commit()         
    db.close()

def get_data(i_dataset_number):
    sql = f''' 
        select * FROM automl_file_db.`{i_dataset_number}`;  
        ''' 
    original_db = pd.read_sql_query(sql, engine)     
    
    return original_db


def add_poly_function(original_data, new_col_name, Variable_poly_new_list):
    tmp_count = 0
    for used_col in Variable_poly_new_list:
        try:
            if tmp_count == 0:
                original_data[new_col_name] = original_data[used_col]
            else:
                original_data[new_col_name] = original_data[new_col_name] + original_data[used_col]
        except Exception as ex_fun:
            print("add fail")
            print(ex_fun)

        tmp_count += 1
    return original_data

def substract_poly_function(original_data, new_col_name, Variable_poly_new_list):
    tmp_count = 0
    for used_col in Variable_poly_new_list:
        try:
            if tmp_count == 0:
                original_data[new_col_name] = original_data[used_col]
            else:
                original_data[new_col_name] = original_data[new_col_name] - original_data[used_col]
        except Exception as ex_fun:
            print("sub fail")
            print(ex_fun)
        tmp_count += 1
    return original_data

def multiply_poly_function(original_data, new_col_name, Variable_poly_new_list):
    tmp_count = 0
    for used_col in Variable_poly_new_list:
        print(used_col)
        try:
            if tmp_count == 0:
                original_data[new_col_name] = original_data[used_col]
            else:
                original_data[new_col_name] = original_data[new_col_name] * original_data[used_col]
        except Exception as ex_fun:
            print("multi fail")
            print(ex_fun)
        tmp_count += 1
    return original_data

def divide_poly_function(original_data, new_col_name, Variable_poly_new_list):
    tmp_count = 0
    for used_col in Variable_poly_new_list:
        
        try:
            if tmp_count == 0:
                original_data[new_col_name] = original_data[used_col]
            else:
                original_data[new_col_name] = original_data[new_col_name] / original_data[used_col]
        except Exception as ex_fun:
            print("divide fail")
            print(ex_fun)
        tmp_count += 1
    return original_data

def square_poly_function(original_data, new_col_name, Variable_poly_new_list):
    
    for used_col in Variable_poly_new_list:
       
        try:
            original_data[new_col_name] = np.square(original_data[used_col])
        except Exception as ex_fun:
            print("square fail")
            print(ex_fun)
            
    return original_data

def square_root_poly_function(original_data, new_col_name, Variable_poly_new_list):
    
    for used_col in Variable_poly_new_list:
       
        try:
            original_data[new_col_name] = np.sqrt(original_data[used_col])
        except Exception as ex_fun:
            print("sqrt fail")
            print(ex_fun)
            
    return original_data

def min_poly_function(original_data, new_col_name, Variable_poly_new_list):
    
    try:
        original_data[new_col_name] = original_data[Variable_poly_new_list].min(axis = 1, skipna = True)
    except Exception as ex_fun:
        print("min fail")
        print(ex_fun)
            
    return original_data

def max_poly_function(original_data, new_col_name, Variable_poly_new_list):
    
    try:
        original_data[new_col_name] = original_data[Variable_poly_new_list].max(axis = 1, skipna = True)
    except Exception as ex_fun:
        print("min fail")
        print(ex_fun)
            
    return original_data

def avg_poly_function(original_data, new_col_name, Variable_poly_new_list):
    
    try:
        original_data[new_col_name] = original_data[Variable_poly_new_list].mean(axis = 1, skipna = True)
    except Exception as ex_fun:
        print("min fail")
        print(ex_fun)
            
    return original_data

def bin_poly_function(original_data, new_col_name, Variable_poly_new_list):
    
    try:
        
        data = original_data
        # only do if features are given
        features_to_discretize = Variable_poly_new_list
        if len(features_to_discretize) > 0:
    
            # place holder for all the features for their binns
            binns = []
            for i in features_to_discretize:
                # get numbr of binns
                hist, _ = np.histogram(data[i], bins="sturges")
                binns.append(len(hist))
    
            # how many colums to deal with
            len_columns = len(features_to_discretize)
            # now do fit transform
            disc = KBinsDiscretizer(
                n_bins=binns, encode="ordinal", strategy="kmeans"
            )
            data_t = disc.fit_transform(
                np.array(data[features_to_discretize]).reshape(
                    -1, len_columns
                )
            )
            # make pandas data frame
            data_t = pd.DataFrame(
                data_t, columns=[str(new_col_name) + "_" + ss for ss in features_to_discretize], index=data.index, 
            )
            # all these columns are catagorical
            data_t = data_t.astype(str)
            # # drop original columns
            # data.drop(features_to_discretize, axis=1, inplace=True)
            # add newly created columns
            data = pd.concat((data, data_t), axis=1)
            
        original_data = data
    except Exception as ex_fun:
        print("bin fail")
        print(ex_fun)

            
    return original_data

def remove_poly_function(original_data, Variable_poly_new_list):    
    for used_col in Variable_poly_new_list:
       
        try:
            original_data = original_data.drop(columns = [used_col])
        except Exception as ex_fun:
            print("square fail")
            print(ex_fun)
            
    return original_data

if __name__== "__main__":
    
    parent_id = os.getpid()
    print(parent_id)    
    # import psutil
    # p = psutil.Process(parent_id)
    # print("暫停")
    # p.suspend()  #掛起程序
    # p.resume() # 恢復程序

    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['transform_data_database']['server']
    DBuser = config['transform_data_database']['DBuser']
    password = config['transform_data_database']['password']
    transdb_database = config['transform_data_database']['database']
    database = config['database']['database']
    port = int(config['transform_data_database']['port'])

    transdb_engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{transdb_database}")    
    engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")    

    '''input 參數'''
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--transdb_number', type=str, default="")
    parser.add_argument('--dataset_number', type=str, default="")  
    
    args = parser.parse_args()
    i_transdb_number = args.transdb_number #參數
    i_dataset_number  = args.dataset_number #參數  
    
    '''joy test'''
    # i_transdb_number = "220118084240"
    # i_dataset_number = "211209113830"
    
    # 載入初始設定, 並寫入資料庫
    sql = f''' 
        select * FROM automl_db.transformed_dataset_info WHERE transformed_dataset_number = '{i_transdb_number}';    
        ''' 
    transdb_setup = pd.read_sql_query(sql, transdb_engine)           
    
    i_dataset_number  = transdb_setup.iloc[0]["used_dataset_number"] #參數
    i_parameter_json  = transdb_setup.iloc[0]["parameter_json"] #參數
    i_parameter_dict = json.loads(i_parameter_json)
    transformed_dataset_file_path = i_parameter_dict['transformed_dataset_file_path']
    i_img_path = i_parameter_dict['path_img']
    i_poly_json_dict = i_parameter_dict['poly_json']
    i_poly_col_list = i_parameter_dict['poly_column_list']   
    
    
    try:
    
        # =============================================================================
        #         取得資料
        # =============================================================================
        try:
            use_data = get_data(i_dataset_number)
        except Exception as ex:
            print(ex)
            status_change(i_transdb_number,"fail (type 1)")
            exit
        
        # =============================================================================
        #     逐一處理新增的column
        # =============================================================================       
        transformed_data = use_data.copy()
        remove_col_list = list()
        for mix_new_col_key in i_poly_col_list:                     
            
            '''撈取欲使用的參數'''
            # print(mix_new_col_key)
            i_Variable_poly_new_str = i_poly_json_dict[mix_new_col_key]['Variable_poly_new_list']
            i_Variable_poly_new_operator = i_poly_json_dict[mix_new_col_key]['Variable_poly_new_operator']
            i_Variable_poly_new_operator = i_Variable_poly_new_operator.strip()
            i_Variable_poly_new_list = i_Variable_poly_new_str.split(" 、 ")
            
            '''移除缺失值'''
            transformed_data = transformed_data.dropna(subset=i_Variable_poly_new_list)
            
            if i_Variable_poly_new_operator == "add":
                transformed_data = add_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "subtract":
                transformed_data = substract_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "multiply":
                transformed_data = multiply_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "divide":
                transformed_data = divide_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "Square":
                transformed_data = square_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "square root":
                transformed_data = square_root_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "min":
                transformed_data = min_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "max":
                transformed_data = max_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "avg":
                transformed_data = avg_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "bin":
                transformed_data = bin_poly_function(transformed_data, mix_new_col_key, i_Variable_poly_new_list)
            elif i_Variable_poly_new_operator == "remove":
                # 暫存欲移除欄位
                remove_col_list = remove_col_list + i_Variable_poly_new_list
                        
        # =============================================================================
        #     欲移除的欄未作後處理            
        # =============================================================================
        transformed_data = remove_poly_function(transformed_data, remove_col_list) 
        
        # =============================================================================
        #     轉換完成 存回資料庫 / csv    
        # =============================================================================
        transformed_data.to_csv(transformed_dataset_file_path,index=False)
        # =============================================================================
        #      轉換完成
        # =============================================================================
        status_change(i_transdb_number,"transformation OK")
        
        print("transformation OK")
        
    except Exception as ex:
        status_change(i_transdb_number,"transformation fail")
        print(ex)
        print("transformation fail")
        exit
        
        
    
    try:
        print("開始")
        init_fun(transformed_dataset_file_path, i_transdb_number, i_img_path)
        
    except Exception as ex_profile:
        print("失敗")
        print(ex_profile)
    
    
    
    