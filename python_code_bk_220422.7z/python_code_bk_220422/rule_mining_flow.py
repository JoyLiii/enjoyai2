# -*- coding: utf-8 -*-
"""
Created on Mon Nov  8 15:10:33 2021

@author: joywcli
"""
import os
os.environ['NUMEXPR_MAX_THREADS'] = '16'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import argparse #承接網頁傳回的參數
import configparser
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import json
from distutils.util import strtobool
import configparser
import warnings

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import Association_rules_Apriori as apr

from sklearn.feature_selection import VarianceThreshold

def status_change(change_number, update_status):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.association_rule_list SET association_rule_status='{update_status}' WHERE association_rule_id='{change_number}';"                 
    cursor.execute(sql)
    #提交修改
    cursor.close()
    db.commit()         
    db.close()
 
def result_change(change_number, update_result, update_item):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    
    #資料庫連線設定
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    sql = f" UPDATE automl_db.association_rule_list SET {update_item}='{update_result}' WHERE association_rule_id='{change_number}';"                 
    cursor.execute(sql)
    #提交修改
    cursor.close()
    db.commit()         
    db.close()  
    
def get_data_and_change_target_label(i_dataset_number):
    sql_type = f''' 
        select variable FROM automl_file_detail_db.`{i_dataset_number}` WHERE logType IN ('Categorical','Numeric');    
    '''     
    type_df = pd.read_sql_query(sql_type, engine)     
    type_list = "`" + "`,`".join(list(type_df['variable'])) + "`"
    
    
    
    sql = f''' 
        select {type_list} FROM automl_file_db.`{i_dataset_number}`;  
    ''' 
    train_file_db = pd.read_sql_query(sql, engine)     
    
    return train_file_db


if __name__== "__main__":
    
    parent_id = os.getpid()
    print(parent_id)    
    # import psutil
    # p = psutil.Process(parent_id)
    # print("暫停")
    # p.suspend()  #掛起程序
    # p.resume() # 恢復程序

    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['rule_database']['server']
    DBuser = config['rule_database']['DBuser']
    password = config['rule_database']['password']
    rule_database = config['rule_database']['database']
    database = config['database']['database']
    port = int(config['rule_database']['port'])

    rule_engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{rule_database}")    
    engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")    


    '''input 參數'''
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--association_rule_number', type=str, default="")
    parser.add_argument('--dataset_number', type=str, default="")   
    
    args = parser.parse_args()
    i_association_rule_number = args.association_rule_number #參數
    i_dataset_number  = args.dataset_number #參數   
    
    '''joy test'''
    # i_association_rule_number = "2112081427561"
    # i_dataset_number = "211202185046"
    
    # 載入模型初始設定, 以便寫入資料庫
    sql = f''' 
        select target, class_label_str FROM automl_db.association_rule_list WHERE association_rule_id = '{i_association_rule_number}';    
        ''' 
    rule_setup = pd.read_sql_query(sql, rule_engine)           
        
    i_target  = rule_setup.iloc[0]["target"] #參數 目標
    i_neg_label  = rule_setup.iloc[0]["class_label_str"] #target類別 參數      
    
    status_change(i_association_rule_number,"start rule python")
    
    # '''joy test'''
    # i_association_rule_number = "rule_test"
    # i_dataset_number = "211108153030"
    # i_target = "y"
    # i_neg_label = "1"
    try:
        
        
        # =============================================================================
        #         取得資料
        # =============================================================================
        try:
            use_data = get_data_and_change_target_label(i_dataset_number)
        except Exception as ex:
            print(ex)
            status_change(i_association_rule_number,"fail (type 1)")
            exit
                
            
            
        '''
        先轉換 要觀察的label ex.NG
        
        '''
        # =============================================================================
        #         要觀察的label 轉換成 1，其他轉成0
        # =============================================================================
        use_data[i_target] = [1 if str(x) == i_neg_label else 0 for x in use_data[i_target]]
        
        
        # =============================================================================
        #         將沒有差異性的特徵提前移除
        # =============================================================================
        for a in list(use_data.columns):           
            if (len(use_data[a].value_counts()) <= 1) and (a != i_target):
                use_data = use_data.drop([a], axis=1)         
        
        # =============================================================================
        #       開始執行 association rule
        # =============================================================================
        support_list =  [0.5,0.6,0.7,0.8,0.9]
        confidence_list = [0.5,0.6,0.7,0.8,0.9]
        final = pd.DataFrame()
        final_df = pd.DataFrame()        
        
        for s_list in support_list:
            for c_list in confidence_list:                
                if len(final_df) < 1:
                    try:
                        # start rule function
                        RA = apr.RulesApriori(min_support=s_list, min_confidence=c_list, min_lift=0.6, check_size=22)
                        final, final_df = RA.run(use_data, y_col=i_target, Input_categorical_col=[])
                        
                        # Key feature
                        key_feature = RA.key_feature
                        
                        # cluster
                        cluster = RA.range_cluster
                    except Exception as ex1:
                        print(ex1)
                        print("fail")
                        pass

                else:
                    break
                
            if len(final_df) > 0:
                break
            
        '''
        再轉換 要反觀察的label ex.OK
        
        '''          
        
        # =============================================================================
        #         取得資料
        # =============================================================================
        try:
            use_data = get_data_and_change_target_label(i_dataset_number)
        except Exception as ex:
            print(ex)
            status_change(i_association_rule_number,"fail (type 1)")
            exit
        
        # =============================================================================
        #         要觀察的label 轉換成 1，其他轉成0
        # =============================================================================
        use_data[i_target] = [0 if str(x) == i_neg_label else 1 for x in use_data[i_target]]
        
        
        # =============================================================================
        #         將沒有差異性的特徵提前移除
        # =============================================================================
        for a in list(use_data.columns):           
            if (len(use_data[a].value_counts()) <= 1) and (a != i_target):
                use_data = use_data.drop([a], axis=1)         
        
        # =============================================================================
        #       開始執行 association rule
        # =============================================================================
        support_list =  [0.5,0.6,0.7,0.8,0.9]
        confidence_list = [0.5,0.6,0.7,0.8,0.9]
        final_OK = pd.DataFrame()
        final_df_OK = pd.DataFrame()        
        
        for s_list in support_list:
            for c_list in confidence_list:                
                if len(final_df_OK) < 1:
                    try:
                        # start rule function
                        RA = apr.RulesApriori(min_support=s_list, min_confidence=c_list, min_lift=0.6, check_size=22)
                        final_OK, final_df_OK = RA.run(use_data, y_col=i_target, Input_categorical_col=[])
                        
                        # Key feature
                        key_feature_OK = RA.key_feature
                        
                        # cluster
                        cluster_OK = RA.range_cluster
                    except Exception:
                        print("fail")
                        pass

                else:
                    break
                
            if len(final_df_OK) > 0:
                break
            

        
        if len(final_df_OK) > 0:            
            # =============================================================================
            # 開始針對 NG 與 OK 的相似度frozenset做結合
            # =============================================================================
            final_df["ok_antecedents"] = ""
            final_df["ok_consequents"] = ""
            final_df["ok_antecedent support"] = 0
            final_df["ok_consequent support"] = 0
            final_df["ok_support"] = 0
            final_df["ok_confidence"] = 0
            final_df["ok_lift"] = 0
            final_df["ok_leverage"] = 0
            final_df["ok_conviction"] = 0    
            final_df["ok_index"] = 0    
            
            final_df["sub_antecedent support"] = 0
            final_df["sub_consequent support"] = 0
            final_df["sub_support"] = 0
            final_df["sub_confidence"] = 0
            final_df["sub_lift"] = 0
            final_df["sub_leverage"] = 0
            final_df["sub_conviction"] = 0    
            final_df["sub_index"] = 0  
            
            if len(final_df) > 1:
                for ng_set_index in range(len(final_df)):
                    for ok_set_index in range(len(final_df_OK)):
                        if (len(final_df.loc[ng_set_index,"consequents"]) == len(final_df_OK.loc[ok_set_index,"consequents"]) and  (len(final_df.loc[ng_set_index,"consequents"].intersection(final_df_OK.loc[ok_set_index,"consequents"])) == len(final_df.loc[ng_set_index,"consequents"])) 
                            ):                       
                            
                            
                            # final_df.loc[ng_set_index, "ok_antecedents"] = final_df_OK.loc[ok_set_index, "antecedents"]
                            # final_df.loc[ng_set_index,"ok_consequents"] = final_df_OK.loc[ok_set_index,"consequents"]
                            final_df.loc[ng_set_index,"ok_antecedent support"] =  final_df_OK.loc[ok_set_index,"antecedent support"]
                            final_df.loc[ng_set_index,"ok_consequent support"] = final_df_OK.loc[ok_set_index,"consequent support"]
                            final_df.loc[ng_set_index,"ok_support"] = final_df_OK.loc[ok_set_index,"support"]
                            final_df.loc[ng_set_index,"ok_confidence"] = final_df_OK.loc[ok_set_index,"confidence"]
                            final_df.loc[ng_set_index,"ok_lift"] = final_df_OK.loc[ok_set_index,"lift"] 
                            final_df.loc[ng_set_index,"ok_leverage"] = final_df_OK.loc[ok_set_index,"leverage"]
                            final_df.loc[ng_set_index,"ok_conviction"] = final_df_OK.loc[ok_set_index,"conviction"]      
                            final_df.loc[ng_set_index,"ok_index"] = ok_set_index   
                            
                            
    
                final_df.loc[:,"sub_support"] = final_df.loc[:,"support"] - final_df.loc[:,"ok_support"]
                final_df.loc[:,"sub_confidence"] = final_df.loc[:,"confidence"] - final_df.loc[:,"ok_confidence"]                        
                final_df.loc[:,"sub_lift"] = final_df.loc[:,"lift"] - final_df.loc[:,"ok_lift"]           
                            
                            
                            
            else:
                print("ng 沒有推薦關聯性")
    
            # =============================================================================
            #         選出相減後篩選後 ， 挑選出confidence > 0 的資料
            # =============================================================================
                    
            
            final_df_sub = final_df[final_df['sub_confidence'] > 0]
            
            
        else:
            final_df_sub = final_df
                

        
        
        # =============================================================================
        #       # frozenset 轉 list or string  
        # =============================================================================
        if len(final_df_sub) > 0:
            final_df_sub.loc[:,"antecedents"] = final_df_sub.loc[:,"antecedents"].apply(lambda x: list(x)[0]).astype("unicode")
            final_df_sub.loc[:,"consequents"] = final_df_sub.loc[:,"consequents"].apply(lambda x: " , ".join(list(x)))
            final_df_sub.replace([np.inf, -np.inf], np.nan, inplace=True)
        else:
            final = pd.DataFrame()
            final_df_sub = pd.DataFrame()        
        
        # =============================================================================
        #         # 將key feature 轉存
        #         # 並將cluster 選取需要的 key feature 
        # =============================================================================
        key_feature_cluster = pd.DataFrame(columns=['cluster_feature','Center','Range'])       
        
        try:
            for x_key in key_feature:
                if "_cluster" in x_key:
                    x_key_list = x_key.split("_cluster")
                    cluster_center = cluster.loc[x_key_list[0]]['cluster' + x_key_list[1] + "_Center"]
                    cluster_range = cluster.loc[x_key_list[0]]['cluster' + x_key_list[1] + "_Range"]
                    
                    new=pd.DataFrame({'cluster_feature':x_key,
                                      'Center':cluster_center,
                                      'Range':cluster_range},
                                     index=[1])  
                    
                    key_feature_cluster = key_feature_cluster.append(new,ignore_index=True)       
            
        except Exception as ex3:
            status_change(i_association_rule_number,"rule fail(3)")
            exit
        
        key_feature_cluster_js = key_feature_cluster.to_json(orient = 'records')  
        key_feature_str = " , ".join(key_feature)
        
        # =============================================================================
        #       開始繪圖
        # =============================================================================
        # 兩兩配對
        permutation_list = list()
        for cons_str in final_df_sub["consequents"]:
            cons_str_list = list()
            cons_str_list.append(i_target)
            cons_str_list.extend(cons_str.split(" , "))
            
            # print(cons_str_list)
        
            import itertools
            permutation_list.extend(list(itertools.combinations(cons_str_list,2)))
        # 濾除重複
        from collections import Counter
        permutation_list_key = list(Counter(permutation_list).keys())
        permutation_list_values = list(Counter(permutation_list).values())
        
        permutation_list_key_df = pd.DataFrame(permutation_list_key, columns=['key1','key2'])
        # permutation_list_key_df['values'] = permutation_list_values
        permutation_array = np.array(permutation_list_key_df)
        permutation_list_tmp = permutation_array.tolist()
        permutation_str = str(permutation_list_tmp)
        # permutation_str = "                                Highcharts.addEvent(                                     Highcharts.Series,                                     'afterSetOptions',                                     function (e) {                                          var colors = Highcharts.getOptions().colors,                                             i = 0,                                             nodes = {};                                         if (                                             this instanceof Highcharts.seriesTypes.networkgraph &&                                             e.options.id === 'language-tree'                                         ) {                                             e.options.data.forEach(function (link) {                                                  if (link[0] === 'y') {                                                     nodes['y'] = {                                                         id: 'y',                                                         marker: {                                                             radius: 20                                                         },                                                         color: colors[3]                                                     };                                                     //nodes[link[1]] = {                                                     //    id: link[1],                                                     //    marker: {                                                     //        radius: 18                                                     //    },                                                     //    color: colors[i++]                                                     //};                                                 } else if (nodes[link[0]] && nodes[link[0]].color) {                                                     nodes[link[1]] = {                                                         id: link[1],                                                         color: nodes[link[0]].color                                                     };                                                 }                                             });                                              e.options.nodes = Object.keys(nodes).map(function (id) {                                                 return nodes[id];                                             });                                         }                                     }                                 );                                  Highcharts.chart('container2', {                                     chart: {                                         type: 'networkgraph',                                         marginTop: 40                                     },                                     title: {                                         text: 'Association Rules with Target'                                     },                                     subtitle: {                                         text: 'Target : y'                                     },                                     plotOptions: {                                         networkgraph: {                                             keys: ['from', 'to', 'width'],                                             layoutAlgorithm: {                                                 enableSimulation: true,                                                 integration: 'verlet',                                                 linkLength: 120                                             }                                         }                                     },                                     series: [{                                         id: 'language-tree',                                         marker: {                                             radius: 10                                         },                                         dataLabels: {                                             enabled: true,                                             //textPath: {                                             //    enabled: true                                             //},                                             linkFormat: '',                                             allowOverlap: false                                          },                                         data:" + permutation_str + "}]                                });"
        permutation_str = permutation_str.replace("'",'"')
        # permutation_list_key_df_copy = permutation_list_key_df.copy()

        # # permutation_list_uniq = list(set(permutation_list))
        # for i in range(len(permutation_list_key_df_copy)):
        #     for j in range(i, len(permutation_list_key_df_copy)):
        #         # print(permutation_list_key_df.iloc[i])
        #         try:
        #             if (permutation_list_key_df_copy.loc[i]["key1"] == permutation_list_key_df_copy.loc[j]["key2"]) and (permutation_list_key_df_copy.loc[i]["key2"] == permutation_list_key_df_copy.loc[j]["key1"]):
        #                 permutation_list_key_df_copy.loc[i,"values"]  = int(permutation_list_key_df_copy.loc[i]["values"])  + int(permutation_list_key_df_copy.loc[j]["values"]) 
        #                 permutation_list_key_df_copy.drop(index=[j])
        #                 print(permutation_list_key_df_copy.loc[i]["key1"] + permutation_list_key_df_copy.loc[i]["key2"] + str(int(permutation_list_key_df_copy.loc[i]["values"])  + int(permutation_list_key_df_copy.loc[j]["values"]) ))
        #         except Exception as ex:
        #             print(ex)
        #             # print("next")


            
        
 
        # =============================================================================
        #        # 將結果table轉存資料庫
        # =============================================================================        
        try:
            # 將新建的DataFrame儲存為MySQL中的資料表，不儲存index列
            if len(final_df_sub) >0:
                final_df_sub.to_sql(i_association_rule_number, rule_engine, if_exists='replace', index = False)
            
            result_change(i_association_rule_number, key_feature_cluster_js,"association_rule_cluster")
            result_change(i_association_rule_number, key_feature_str,"association_rule_key_feature")
            result_change(i_association_rule_number, permutation_str,"association_rule_plot")
        except Exception as ex2:
            status_change(i_association_rule_number,"rule fail(4)")
            print(ex2)        
        
        status_change(i_association_rule_number,"rule OK")
        print("rule OK")
        
    except Exception as ex:
        status_change(i_association_rule_number,"rule fail")
        print(ex)
        print("rule fail")


    # #==========================================================
    # ## If you want to try, it can help you.
    
    # # Sample data
    # df_data = pd.read_excel(r'D:\Pycaret\MMFA會議\關聯性分析\宗翰\bktest\fakedata.xlsx', index_col=[0])
    # # df_data = pd.read_csv(r'D:\Pycaret\MMFA會議\關聯性分析\宗翰\credit.csv')
    # # df_data = pd.read_csv(r'D:\Pycaret\Max_test\raw_overall_classify.csv')  
    # i_neg_label = str(1)    
    
    
    # # 設定target
    # i_target = "y"
    # df_data[i_target] = [1 if str(x) == i_neg_label else 0 for x in df_data[i_target]]
    
    
    # for a in list(df_data.columns):
       
    #     if (len(df_data[a].value_counts()) <= 1) and (a != i_target):
    #         print(a)
    #         df_data = df_data.drop([a], axis=1)
               


    # # For test
    # RA = apr.RulesApriori(min_support=0.6, min_confidence=1, min_lift=1, check_size=22)
    # final, final_df = RA.run(df_data, y_col=i_target, Input_categorical_col=[])
    
    # # frozenset 轉 list or string
    # final_df["antecedents"] = final_df["antecedents"].apply(lambda x: list(x)[0]).astype("unicode")
    # final_df["consequents"] = final_df["consequents"].apply(lambda x: " , ".join(list(x)))
    
    # # Key feature
    # key_feature = RA.key_feature
    
    # # cluster
    # cluster = RA.range_cluster
    # #==========================================================

    # # 初始化資料庫連線，使用pymysql模組
    # # MySQL的使用者：root, 密碼:147369, 埠：3306,資料庫：mydb
    # '''SQL Server info'''
    # config = configparser.ConfigParser()
    # config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    # server = config['rule_database']['server']
    # DBuser = config['rule_database']['DBuser']
    # password = config['rule_database']['password']
    # database = config['rule_database']['database']
    # port = int(config['rule_database']['port'])

    # engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")

        
    # # 將新建的DataFrame儲存為MySQL中的資料表，不儲存index列
    # final_df.to_sql('demo_rule1115', engine, if_exists='append', index = False)
    # print('Read from SHIFT and write to Mysql table successfully!')

