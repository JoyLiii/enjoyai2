# -*- coding: utf-8 -*-
"""
Created on Mon Nov  8 15:10:33 2021

@author: joywcli
"""
import os
os.environ['NUMEXPR_MAX_THREADS'] = '16'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import argparse #承接網頁傳回的參數
import configparser
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import json
from distutils.util import strtobool
import configparser
import warnings
import psutil

import pandas as pd
import numpy as np

 


if __name__== "__main__":
    
    parent_id = os.getpid()
    print(parent_id)    
    p = psutil.Process(parent_id)
    print("暫停")
    p.suspend()
    print("繼續")
    p.resume()