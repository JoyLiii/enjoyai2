# -*- coding: utf-8 -*-
"""
Created on Thu Dec  3 11:28:25 2020

@author: JoyWCLi
"""


import asyncio
import json
from pyppeteer import launch
from pyppeteer.network_manager import Request
from bs4 import BeautifulSoup
import pandas as pd
from pyquery import PyQuery as pq
import io

uid = '2020/10/23' #NT帳號
password = '2020/11/23' #NT密碼

async def main():
# 開啟瀏覽器程序.
    browser = await launch({'headless': True , 'args': ['--no-sandbox','--disable-setuid-sandbox',]},executablePath='chrome-win/chrome.exe',ignoreHTTPSErrors=True)
    page = await browser.newPage()
    url ='http://l6am0-srv1.corpnet.auo.com/AR/MQC_RECORD/Etch_Rate/Etch_Rate_Record.aspx'
    res = page.post(url).text
    soup = BeautifulSoup(res)
    __VIEWSTATE = soup.find('input',{'id':'__VIEWSTATE'}).get('value')
    __VIEWSTATEGENERATOR = soup.find('input',{'id':'__VIEWSTATEGENERATOR'}).get('value')
    data = { 
            "__VIEWSTATE": [__VIEWSTATE], 
            "__VIEWSTATEGENERATOR": [__VIEWSTATEGENERATOR], 
            "txt_MFG_DAY_FROM": ["2020/11/10"], 
            "txt_MFG_DAY_To": ["2020/12/03"], 
            "btn_query": ["Query"]
            }
    res = page.post(url,data=data).text
    df = pd.read_html(io.StringIO(res))
    
#    
#    
#    await page.goto(url)   
#    await page.waitForSelector('#txt_MFG_DAY_FROM')
#    await page.click('#txt_MFG_DAY_FROM');
#    await page.keyboard.down('Control');
#    await page.keyboard.press('KeyA');
#    await page.keyboard.up('Control');
#    await page.keyboard.press('Backspace');
#    await page.type('#txt_MFG_DAY_FROM', uid)
#    await page.click('#txt_MFG_DAY_To');
#    await page.keyboard.down('Control');
#    await page.keyboard.press('KeyA');
#    await page.keyboard.up('Control');
#    await page.keyboard.press('Backspace');
#    await page.type('#txt_MFG_DAY_To', password)
##    await page.click('#btn_query')
#    await asyncio.sleep(3)
#    # 鼠标模拟点击（类似于毫无目的的在屏幕上点击，迷惑对方）
#    page.mouse
#    # 点击提交，并等待页面正确响应。
#    await asyncio.gather(
#      page.click("#btn_query"),
#      page.waitForNavigation(),
#    )
##    await asyncio.sleep(10)
##    await page.keyboard.press('Tab');
##    await page.keyboard.press('Tab');
##    await page.keyboard.press('Tab');
##    await page.keyboard.press('Tab');
##    await page.keyboard.press('Tab');
##    await page.keyboard.press('Enter');
##    await asyncio.sleep(30)
##    await page.waitForSelector('#Raw_Table_next')
##    await page.mouse.down('#Raw_Table_next');
##    await page.mouse.up('#Raw_Table_next');
##    await page.waitForSelector('#Raw_Table_next')
##    await page.click('#Raw_Table_next');
#    await asyncio.sleep(10)
##    await page.goto('view-source:http://l6am0-srv1.corpnet.auo.com/AR/MQC_RECORD/Etch_Rate/Etch_Rate_Record.aspx')
#    await page.keyboard.down('Control')
#    await page.keyboard.press('KeyU');
##    html_doc = await page.content()
##    await page.waitForSelector('#WMA_Table')
#    await asyncio.sleep(3)
#    doc = await page.plainText()
    await browser.close()
    return df
html_doc = asyncio.get_event_loop().run_until_complete(main())
#soup = BeautifulSoup(html_doc, 'lxml')
#table = soup.select('.table')
df2 = pd.read_html(html_doc)
print(df2)




