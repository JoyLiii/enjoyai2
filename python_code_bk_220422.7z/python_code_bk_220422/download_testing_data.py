# -*- coding: utf-8 -*-
"""
Created on Tue Nov 23 17:35:29 2021

@author: joywcli
另存測試結果 xlsx
"""
import argparse #承接網頁傳回的參數
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import configparser

if __name__== "__main__":
    try:
        parser = argparse.ArgumentParser(description='')
        parser.add_argument('--dataset_number', type=str, default="")
        parser.add_argument('--path', type=str, default="")
        args = parser.parse_args() 
        
        i_path  = args.path # train 檔案名稱
        i_dataset_number  = args.dataset_number # train 檔案名稱
         
        '''SQL Server info'''
        config = configparser.ConfigParser()
        config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
        server = config['database']['server']
        DBuser = config['database']['DBuser']
        password = config['database']['password']
        database = config['testing_result_data_database']['database']
        port = int(config['database']['port'])
        
        engine = create_engine(f"mysql+pymysql://{DBuser}:{password}@localhost:{port}/{database}")    
        
        # =============================================================================
        #  joy test
        # =============================================================================
        # i_dataset_number = "211122102426"
        
        sql = f''' 
            select * FROM automl_testing_result_db.`{i_dataset_number}`;    
        ''' 
        data_df = pd.read_sql_query(sql, engine)
        data_df.to_excel(i_path + i_dataset_number + "_result.xlsx",index=False)
        
        print("download OK")
    except Exception as ex:
        print(ex)
        print("download fail")
        