"""
Created on Fri Jan  7 11:45:50 2022

@author: fc860
"""
import ctypes

#vendor code
vendorCode = "GCvSll31KWbbepnAAYUnaPF2Nm4OspeXvRQCHqE6QZHKb5gZkrlfFPCpzNwcyfT4dfLMRSgY7/Lbb4UY" \
    "7CvJtX0AAGVQfluR0p/OlOU6gyFO1wpiT8CfXxddohLTJKGe0KP5qaXibTtCFylm9cIyf3KBUrbsHmgm" \
    "KK7uhFvUa4WFTzncKYSgC2kGKTaWXvA9BSEG3JilyC0oLaTTOBaa3sCmus8HzjrnrIC7cG70hhvL5J8K" \
    "ZTLXzAIJn2gt8MMB5DyI5hmrB0SavaBbHgk3m0YEBv73qrdf+mwmxCMxoTGw6VrMXdEuTX0xUPuspMbI" \
    "UPTCu6W236G7OEifAT/aCuMCOCab4jrm/A7GPj+sbvPDtywPVRN+4KJxKkywutbs4VFzHQhWaoXCQHdv" \
    "guT9rDAyoNIR+9DTfV3YW0YtH2TKSTXtVCQNa2W1BFTPZUkEoE1Zl0Svbzoy+19yQRyV99+Q8SCjGNUU" \
    "ZLTEbVclChPR8qHocugxCtPIXlaWCAdxKq03OdD3Q8qw+BmWu64k/nmE9Cwe9lQLGC0YnVvIn/GQGp6M" \
    "XZfZuVOgjXcfKmjnddwZa8wKoVDJcBgjfSin6SusbZpwcctNPqiEzbjZ4gkZ0WpqSZzbf5Uo12uDY2oy" \
    "zpYBQ/ew8H2ahYxrTQMLTPCJt+PQkPt54wI72aaKySq9iZVyvVu0LjH4PVmYTHht4FrT435AdAqADJDQ" \
    "Kh1HHqOiXPTzZgo8ZPjLz1VgW72ozpKaru8LWprvkp9BCi6Gi5hynWqNDKTBx7dRP0v07ZFS35gWwqcg" \
    "fRqWDiL8vYOiTWAC7gTWpNkPWS4eC30pgyuAx7AFEo+BUAX7zpxqy4H5HKVAjYP86SVMs1Js+eDzBJJx" \
    "vvM/n/wM7jrC9FBzwkMvElFLhViO9M3TkTccascxu+JAavtncoczyzWGUTrHFMr8ZKHpSuqXoQPqYAJO" \
    "Kd81MHbcZNl4uojekW7w5A=="

#轉成C、配置featureID
pstrvendorcode = ctypes.c_char_p()
pstrvendorcode.value = vendorCode.encode()
handle = ctypes.c_uint32()
intFeatureID = ctypes.c_uint32(1)
intreturnstatus = ctypes.c_uint32()

hasplib = ctypes.CDLL("hasp_windows_x64_112979.dll")

#呼叫hasp
intreturnstatus = hasplib.hasp_login(intFeatureID,pstrvendorcode,ctypes.byref(handle))

if intreturnstatus == 0:
    print("success")

else:
    print("error")
    print("error message code",intreturnstatus)

