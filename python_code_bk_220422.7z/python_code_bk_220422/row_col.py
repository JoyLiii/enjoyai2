# -*- coding: utf-8 -*-
"""
Created on Tue Mar 16 13:32:19 2021

@author: JoyWCLi

回傳row與column的數量

"""

import argparse #承接網頁傳回的參數
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
from io import StringIO
from profiling_function import *

def init_fun(web_path, i_dataset_number, i_img_path):

    #取得網頁OPID_LIST
    web_opid_list = web_path
    web_opid_list = web_opid_list.replace('\\' , '//')
    # web_opid_list = "D:/joy/automl_upload_file/ALL_WIP_YT.xlsx"
    sub_str = web_opid_list[-3:]
    
    rows = 0
    cols = 0
    column_list_str = ""
    type_list_str = ""
    web_opid_list_df = pd.DataFrame()
    if sub_str.lower() == "csv":
        
        try:
            web_opid_list_df = pd.read_csv(web_opid_list,encoding='utf-8' )
            rows = web_opid_list_df.shape[0]
            cols = web_opid_list_df.shape[1]
        except Exception:
            web_opid_list_df = pd.read_csv(web_opid_list,encoding='big5' )
            rows = web_opid_list_df.shape[0]
            cols = web_opid_list_df.shape[1]
    elif sub_str.lower() == "lsx":
        web_opid_list_df = pd.read_excel(web_opid_list)
        rows = web_opid_list_df.shape[0]
        cols = web_opid_list_df.shape[1]
        
    # 資料新增進入資料庫
    from sqlalchemy import create_engine
    import pymysql.cursors
    # 欄位名稱不允許空格
    # 先去除前後的空格，文中的空格用下底線取代
    web_opid_list_df.columns = web_opid_list_df.columns.str.strip()
    web_opid_list_df.columns = web_opid_list_df.columns.str.replace(" ", "_")

    engine = create_engine("mysql+pymysql://{}:{}@{}/{}".format('automl', 'automl$0', 'localhost:3306', 'automl_file_db'))
    con = engine.connect()
    web_opid_list_df.to_sql(name=i_dataset_number, con=con, if_exists='replace', index=False)

        
    type_df = pd.DataFrame(web_opid_list_df.dtypes)
    type_df[0] = type_df[0].apply(lambda _: str(_))
    column_list = pd.Series(type_df.index)
    type_list = pd.Series(type_df[0])
    
    column_list_str = column_list.str.cat(sep='!!')
    type_list_str = type_list.str.cat(sep='!!')
    

    dataset_name = "1"
    column_list = str(column_list_str)
    type_list = str(type_list_str)
    upload_filename = str(web_opid_list)
    size_f_upload = str(os.path.getsize(web_opid_list))
    r=str(rows)
    c=str(cols)
    
    #資料庫連線設定
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    request_table_name = "databse_info2"
    port = int(config['database']['port'])        
    
    # server = '10.96.48.148' #IP:port
    # DBuser = 'automl'
    # password = 'automl$0'
    # database = 'automl_db'
    # request_table_name = "databse_info2"
    # port = 3306
            
    db = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')
    #建立操作游標
    cursor = db.cursor()
    #SQL語法
    # sql2 = "INSERT INTO " + database + "." + request_table_name + " ( Dataset_number,Dataset_name,Row_no, Column_no,Column_list,Type_list,Dataset_status,Dataset_path,Dataset_size,Upload_time ) VALUES ('" + i_dataset_number + "','" + dataset_name + "', " + r + " , " + c + " ,'" + column_list + "' ,'" + type_list + "' ,'資料集上傳111','" + upload_filename + "','" + size_f_upload + "','" + txt_date + "');"
    
    txt_date = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    sql = "UPDATE " + database + "." + request_table_name + " SET Row_no =  " + r + " , Column_no = " + c + "  ,Column_list = '" + column_list + "' ,Type_list =  '" + type_list + "' ,Dataset_status = '資料繪製中' ,Modify_time = '" + txt_date + "' WHERE Dataset_number = '" + i_dataset_number + "';" 
    
    #執行語法
    

    cursor.execute(sql)
    #提交修改
    db.commit()


    db.close()

    # 繪製eatmap / histogram / bar plot
    # i_f_path = "D:/joy/"
    # i_f_path_name = "D:/joy/ALL_WIP_YT.xlsx"

    i_f_number = i_dataset_number
    i_f_path_name  = web_opid_list
    
    name_list = i_f_path_name.split("/")
    name_list.pop()
    i_f_path = "/".join(name_list) + "/"
    
    a = profile_fun(web_opid_list_df,i_f_path, i_f_path_name,i_f_number,i_img_path)
    print('success')
    


def status_change(change_number, update_status):
    '''SQL Server info'''
    config = configparser.ConfigParser()
    config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
    server = config['database']['server']
    DBuser = config['database']['DBuser']
    password = config['database']['password']
    database = config['database']['database']
    port = int(config['database']['port'])

    
    #資料庫連線設定
    db2 = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
    #建立操作游標
    cursor2 = db2.cursor()
    #SQL語法
    sql2 = f" UPDATE automl_db.databse_info2 SET Dataset_status='{update_status}' WHERE Dataset_number='{change_number}';"                 
    cursor2.execute(sql2)
    #提交修改
    cursor2.close()
    db2.commit()         
    db2.close()
    


if __name__== "__main__":
    import matplotlib.pyplot as plt
    plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
    plt.rcParams['axes.unicode_minus']=False #用来正常显示负号
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--path', type=str, default="")
    parser.add_argument('--dataset_number', type=str, default="")
    parser.add_argument('--img_path', type=str, default="")
    args = parser.parse_args() 
    web_path  = args.path #檔案路徑 + 檔案名稱
    i_dataset_number  = args.dataset_number #輸出的結果的目錄路徑
    i_img_path  = args.img_path #圖片存放路徑
    
    # web_path = r"D:\joy\automl_upload_file\220304211652\PA_Model_PIS_raw_data.csv"
    # i_dataset_number = "220304211652"  
    # i_img_path = r"C:\inetpub\wwwroot\AutoML\upload_file_img/220304211652/profiling_data/"
    # i_img_path = i_img_path.replace('\\' , '//')
    
    try:
        init_fun(web_path, i_dataset_number, i_img_path)

    except Exception as ex:
        
        update_status = "fail"
        change_number = i_dataset_number
        '''SQL Server info'''
        config = configparser.ConfigParser()
        config.read('D:\joy\web\AutoML_web_vb\python_file\config.ini')
        server = config['database']['server']
        DBuser = config['database']['DBuser']
        password = config['database']['password']
        database = config['database']['database']
        port = int(config['database']['port'])
    
        
        #資料庫連線設定
        db2 = pymysql.connect(host=server, port=port, user=DBuser, passwd=password, db=database, charset='utf8')       
        #建立操作游標
        cursor2 = db2.cursor()
        #SQL語法
        sql2 = f" UPDATE automl_db.databse_info2 SET Dataset_status='{update_status}' WHERE Dataset_number='{change_number}';"                 
        cursor2.execute(sql2)
        #提交修改
        cursor2.close()
        db2.commit()         
        db2.close()
                    
        print(ex)
        print("fail")
    

    
