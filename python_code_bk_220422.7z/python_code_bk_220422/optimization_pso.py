import numpy as np
import pandas as pd
import pyswarms as ps
from xgboost import XGBClassifier
from xgboost import XGBRegressor

class OPT_PSO:
    """
    Use PSO to find the recommended setting range of key features.
    
    Parameters
    -----
    all_feature : bool, default=True
        Whether to use all features for modeling.
    yInput : int, default=1
        The classification or the regression: either 0 or 1.
    greater : bool, default=False
        Whether y is a defect ratio (default), meaning low is good, 
        or a OK ratio, meaning high is good.
    abs_y : bool, default=False
        Determine whether y needs to take the absolute value.
    """
    
    def __init__(self, all_feature=True, yInput=1, greater=False, abs_y=False):
        """
        Initialization model and some parameters.
        """
        ### Parameter setting
        self.all_feature = all_feature
        self.greater = greater
        self.yInput = yInput
        self.abs_y = abs_y
        
        ### Model setting
        self.xgb_model = XGBRegressor(random_state = 11850)
        
        ### PSO parameter setting
        self.PSO_options = {'c1': 2, 'c2': 2, 'w':0.5}
        
    def feature_spec(self):
        """
        Calculate the ng ratio in each value of key feature, and show five recommended range of key feature.
        The result is recorded in self.spec and provided to function run.
        """
        data_frame = pd.concat([self.X, self.y] ,axis = 1)
        data_frame = data_frame.rename(columns={self.y_column_name:'y'})
        
        spec = pd.DataFrame(columns=['Feature', 'Lower Bound', 'Upper Bound','TOP'])
        for feature in self.key_feature:
            ### Dealing with binomial feature
            if self.X[feature].nunique() == 2:
                spec = spec.append({
                        'Feature': feature,
                        'Lower Bound': self.X[feature].min(),
                        'Upper Bound': self.X[feature].max(),
                        'TOP':'binomial feature'
                        }, ignore_index=True)
                pass
            
            ### Calculate NG ratio
            ### Create a table with the row as the feature and the column as the y
            df_ratio = data_frame.groupby(feature).y.value_counts().unstack(fill_value=0)
            if self.yInput == 0:
                df_ratio = df_ratio.rename(columns={0:'OK', 1:'NG'})
            elif self.yInput == 1:
                ### There is no case of 0
                if df_ratio.columns[0] != 0:
                    df_ratio.insert(0, 0, 0)
                df_ratio['NG'] = ((df_ratio.columns * df_ratio).sum(axis=1)/df_ratio.iloc[:,1:].sum(axis=1)).fillna(0)
                df_ratio = df_ratio.rename(columns={0:'OK'})
            df_ratio['NGratio'] = df_ratio['NG'] / (df_ratio['NG'] + df_ratio['OK'])  
            df_ratio = df_ratio.reset_index().rename(columns={'index':feature}).rename_axis(columns=None)
            
            ### Split with the top five percentiles (5% 10% 40% 80% 90%)
            df_ratio = df_ratio.sort_values(by=['NGratio', feature])
            parts = [[5,round(df_ratio.shape[0]*0.05)],
                    [10,round(df_ratio.shape[0]*0.10)],
                    [40,round(df_ratio.shape[0]*0.40)],
                    [80,round(df_ratio.shape[0]*0.80)],
                    [90,round(df_ratio.shape[0]*0.90)]]
            for top,part in parts:
                if part != 0 and part != 1:
                    part_max = df_ratio.iloc[0:part,0].max()
                    part_min = df_ratio.iloc[0:part,0].min()
                    spec = spec.append({
                        'Feature': feature,
                        'Lower Bound': part_min,
                        'Upper Bound': part_max,
                        'TOP':'{}%'.format(top)
                        }, ignore_index=True)
        self.spec = spec
    
    def fitness(self, x):
        """
        Create a model to predict y value(probability) for combination of feature(x combination).
        
        Parameters
        -----
        x : array of shape n_particles and number of feature
            The particle swarm
            
        Returns
        -----
        y_pred: array of shape n_particles
            The prediction result of each combination.
        """
        x = pd.DataFrame(x)
        f_names = self.xgb_model.get_booster().feature_names
        x.columns = f_names
        y_pred = self.xgb_model.predict(x)
        return y_pred
        
    def run(self, data_frame, key_feature, y_column_name):  
        """
        Choose the range of each key feature in self.spec which include the result of OPT.
        
        Parameters
        -----
        data_frame: dataframe(pandas)
            After data pre-processing, but not yet standardized.
        key_feature: list
            The key features of the model.
        y_column_name: str
            The colume of y in data_frame.
        
        Returns
        -----
        final_recommand: list
            Recommended setting range of key features.
        """
        ### Set input data
        self.y_column_name = y_column_name
        self.X = data_frame.drop([self.y_column_name], axis=1)
        self.y = data_frame[self.y_column_name]
        self.key_feature = key_feature
        ### Adjust y according to greater
        if self.greater:
            self.y = -self.y + 1
        if not self.all_feature:
            self.X = self.X.filter(self.key_feature, axis=1)
        if self.abs_y:
            self.y = abs(self.y)
        
        ### Set lower bound and upper bound for each feature
        low = []
        up = []
        for col in self.X.columns:
            try:
                self.X[col] = self.X[col].astype('float')
                low.append(self.X[col].min())
                up.append(self.X[col].max())
            except:
                print('This column is object.')
        bounds = (low, up)
        
        self.feature_spec()
        
        ### If yInput=0, turn categorical y(0/1) into continuous y(probability).
        if self.yInput == 0:
            xgb_model = XGBClassifier(random_state = 0)
            X_kfeature = self.X.filter(self.key_feature, axis=1)
            xgb_model.fit(X_kfeature, self.y)
            xgb = pd.DataFrame(xgb_model.predict_proba(X_kfeature))
            self.y = xgb.iloc[:,1]
        
        ### Model fitting
        self.xgb_model.fit(self.X.values, self.y)
        
        ### Use PSO method to find out best combination (x combination).
        optimizer = ps.single.GlobalBestPSO(n_particles=10, dimensions=self.X.shape[1], options=self.PSO_options, bounds=bounds)
        cost, pos = optimizer.optimize(self.fitness, iters=100, verbose=False)

        ### Create a table to summarize pso_result(recommanded feature value), lower bound, upper bound and level of each key feature. 
        level = []
        for i in range(len(self.X.columns)):
            level.append(self.X.iloc[:,i].nunique())
        comparison = pd.concat([pd.DataFrame(self.X.columns),
                                pd.DataFrame(pos),
                                pd.DataFrame(low),
                                pd.DataFrame(up),
                                pd.DataFrame(level)],axis=1)
        comparison.columns = ['Feature','pso_result','lower bound','upper bound','level']
        comparison['recommand'] = np.nan
        
        ### Deal with binomial feature
        for col in range(len(self.X.columns)):
            if (comparison.loc[col,'level']==2):
                dist_lower = abs(comparison.loc[col,'pso_result']-comparison.loc[col,'lower bound'])
                dist_upper = abs(comparison.loc[col,'upper bound']-comparison.loc[col,'pso_result'])
                if  dist_lower >= dist_upper:
                    comparison.loc[col,'recommand'] = comparison.loc[col,'upper bound']
                else:
                    comparison.loc[col,'recommand'] = comparison.loc[col,'lower bound']
            else:
                comparison.loc[col,'recommand'] = round(comparison.loc[col,'pso_result'], 1)
        
        ### Determine which range the result of PSO belongs to.
        spec_feature = pd.DataFrame(self.spec['Feature'].drop_duplicates())
        comparison = spec_feature.merge(comparison, on = 'Feature', how = 'inner')
        df_feature_spec = self.spec.set_index('Feature')
        
        final_recommand = pd.DataFrame([])
        for feature in range(len(comparison)):
            temp = pd.DataFrame([])
            feature_name =  comparison.loc[feature,'Feature']
            par = pd.DataFrame(df_feature_spec[df_feature_spec.index == feature_name])
            ### Compare each range(part) in order
            for part in range(len(par)):
                less_upper = comparison.loc[feature,'recommand'] <= float(par['Upper Bound'][part])
                more_lower = comparison.loc[feature,'recommand'] >= float(par['Lower Bound'][part])
                if  less_upper and more_lower:
                    temp = pd.DataFrame(par.iloc[part,:]).T
                    break
            if temp.empty:
                temp = pd.DataFrame(par.iloc[0,:]).T
            ### Deal with binomial feature
            if comparison.loc[feature,'level'] == 2:
                temp['Upper Bound'] = comparison.loc[feature,'recommand']
                temp['Lower Bound'] = comparison.loc[feature,'recommand']
            temp['Raw range'] = str(data_frame[feature_name].min()) + ' ~ ' + str(data_frame[feature_name].max())
            final_recommand = pd.concat([final_recommand, temp], axis=0)
            
        final_recommand = final_recommand.reset_index().drop(['index'], axis=1)
        final_recommand = pd.concat([comparison['Feature'], final_recommand], axis=1)
        final_recommand_df = final_recommand.copy()

        
        ### For json
        ### You can get dataframe when you comment out this line.
        final_recommand = final_recommand.to_dict(orient='records')
        
        return final_recommand, final_recommand_df

#=================================================
### If you want to try, it can help you.
#import optimization_pso as opt
#
#data_frame = 
#key_feature =
#
#OPT = opt.OPT_PSO(all_feature=True,
#                  greater=False,
#                  yInput=0,
#                  abs_y=False)
#
#final = OPT.run(data_frame=data_frame,
#                key_feature=key_feature,
#                y_column_name='Y')
#
#list_spec = OPT.spec
#=================================================
    
    
# if __name__== "__main__":


    # =============================================================================
    #     分類 測試
    # =============================================================================    
    # with open(r'D:\Pycaret\make_result_for_MMFA\參數推薦資料\classification\key_feature.json') as f:
    #     feature_list = json.load(f)    
    # tmp_data = pd.read_excel(r"D:\Pycaret\make_result_for_MMFA\參數推薦資料\classification\dataset2.xlsx")
    
    # # 類別型特徵進行 one hot
    # data_frame = pd.get_dummies(tmp_data)
    
    
    # key_feature = feature_list["key_feature"]
    # key_feature_all = data_frame.columns.to_list()
    # key_feature_all.remove("Y")
    
    # OPT = OPT_PSO(all_feature=True,
    #                   greater=False,
    #                   yInput=0,
    #                   abs_y=False)
    
    # final_json, final_df = OPT.run(data_frame=data_frame,
    #                         key_feature=key_feature_all,
    #                         y_column_name='Y')
    
    # list_spec = OPT.spec
    # print("OK")
    
    # =============================================================================
    #   回歸 測試
    # =============================================================================    
    # with open(r'D:\Pycaret\make_result_for_MMFA\參數推薦資料\regression\key_feature.json') as f:
    #     feature_list = json.load(f)
    # key_feature = feature_list["key_feature"]
    
    # tmp_data = pd.read_excel(r"D:\Pycaret\make_result_for_MMFA\參數推薦資料\regression\dataset.xlsx" )  
    
    # # 類別型特徵進行 one hot
    # df_onehot = pd.get_dummies(tmp_data)
    
    # # target 進行minmax壓縮到 0~1 之間
    # from sklearn.preprocessing import MinMaxScaler
    # scaler = MinMaxScaler()
    # df_onehot["class0"] = scaler.fit_transform(pd.DataFrame(df_onehot["class0"]))
    # data_frame = df_onehot.copy()
    

    # key_feature_all = data_frame.columns.to_list()
    # key_feature_all.remove("class0")
    
    # OPT = OPT_PSO(all_feature=True,
    #                 greater=False,
    #                 yInput=1,
    #                 abs_y=False)
    
    # final_json, final_df = OPT.run(data_frame=data_frame,
    #                 key_feature=key_feature,
    #                 y_column_name='class0')
    
    # list_spec = OPT.spec
    # print("OK")
 


