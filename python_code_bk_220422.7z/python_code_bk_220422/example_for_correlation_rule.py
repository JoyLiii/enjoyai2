# -*- coding: utf-8 -*-
"""
Created on Mon Aug  9 17:37:20 2021

@author: JoyWCLi
"""


import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pycaret.regression import *
from sklearn.linear_model import LinearRegression
from GA_regression import *
import shap


hepatitis = pd.read_excel("D:/Pycaret/WIP_TEST/0317test/ALL_WIP_120.xlsx")
hepatitis = pd.DataFrame(hepatitis)
from pycaret.arules import *
exp = setup(data = hepatitis, transaction_id = 'Y_ALL_WIP', item_id = '4-SIDE')
model1 = create_model(metric = 'confidence')


model = load_model("D:\Pycaret\ML3C02_test\joy_test\method2\RF_model_ML3C02_method2")

import pickle 
# load the model from disk
pickle_model = pickle.load(open("D:\Pycaret\ML3C02_test\joy_test\method2\RF_model_ML3C02_method2.pkl", 'rb'))
result = loaded_model.score(X_test, Y_test)