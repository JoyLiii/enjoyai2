# -*- coding: utf-8 -*-
"""
Created on Fri Mar 19 17:38:51 2021

@author: JoyWCLi
"""

import argparse #承接網頁傳回的參數
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pycaret.regression import *
from sklearn.linear_model import LinearRegression
from GA_regression import *
import shap
from sklearn.model_selection import train_test_split
from sqlalchemy import create_engine,text
import time
import datetime
import pymysql.cursors
import pandas as pd
import matplotlib.pyplot as plt
import pandas_profiling as pdp


# web_opid_list = r"‪D:\joy\automl_upload_file\210823110618\ML3C02_concat_data.csv"
web_opid_list_df = pd.read_csv(r'D:\joy\automl_upload_file\210823110618\ML3C02_concat_data.csv')
web_opid_list_df.describe()
profile = pdp.ProfileReport(web_opid_list_df)
profile.to_file("output.html")  #支援輸出html

import pandas_profiling

pandas_profiling.describe_df(web_opid_list_df)
html_str_output = pandas_profiling.ProfileReport(web_opid_list_df)